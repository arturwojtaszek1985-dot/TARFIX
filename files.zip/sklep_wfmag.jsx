import { useState, useRef, useCallback, useEffect } from "react";
import Papa from "papaparse";

const LOGO_TARFIX = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAhYAAABaCAIAAABrIIi6AABae0lEQVR42u29d5ic53Ufes77fmXaVvRK9A4CIEgQJFgkq9mWbTnWTeJynTg3spU4dhLFckni+EmeG9txEjm24xLbubqKdZ3EvcqOqiWSEQkSjSBI9N4WbcvsznzlLef+8U356uzM7CwwgDkPHhLYnfnmraf8zjm/g8PL1kHLFwIgoiKSQgBRqVQcXbBwydKlIwsWLFm6fGjhYsvOmVYul8tbBkNEZBwZAyAA0FoDAREoKaUUvvCrjuNWypN37966eePW2I3xu3enpiY930fGDW4gAhHBHF4IAMF3h1+MYXXG+caPuh/6dqzOAGNAgNh4PwEAICFg46OIFH4gAgA2nlp7J9Z/jY0vRKr9J/RzDJ6KhPUn1t8Q+q5gCPUfYn0g2PxSQNJYKKjf+yP9xa9AsQhaZ00/ZQVmfTFGlWr+u77V/tDzVKkiC7adgACwOcH6CLE5ZSBAQE2Ys8TpS5Of+iwYLPn13Q8s8ZzmqnnCXrN4xU99DwAAEWBos6Cx4MFaNzaructY24bm8xCQgLC2cVjbcSKsfZgaxwABSGkxXvHHJp2r9yqnx5xLd/270yQ1sw1mGQBAeo5zrU+ZoZjxlrx349Yfe6+s+ohY35HmkOo/qE8ZEYCQQqc6OJBEjbOFwQ+bFyG0Ghg64fGrQbWDAdET3thbTWbJOvIfXr/4Z+etQYtUfBFI03v+04ujW0ekKxlDIkIMH6fmeYvMEQCAmMHcCffz//Bld9JnRuhDCKTILBof+qVnhh4rSVcxDvGj2zwZ1LzX2Dg5FIzNHjAO/+b5g796Jj9sadWDHWQcnUnxvn+5ac93rfSmBfJgRvUpY0OkQHNTmvelPqqiMfbO9O98/B3pa2RzvkU9fRmzHF9ErbUUImdbq9et3bhl6/pNmxctWloaGuJmHriBSIwx0EQEOrhvAEQASAyRMcSaICKttSYNmpQmBBBSua5THr9z8/rVK5cunT9z8u6dO4qIz02R0KwiiCC6RQ3hguFPEyE2hH7wNmoKp9rW1h9HoZOAGD0EERVUeyDFTjYhANXvISJQbJC1s65bzQ6jc0/+s9X6IICUbMGIuXcH+AIxOOGNIx4InsZM6zvcOCJAwJB8YW5abW5a7b9zgeVzqRouObC57i+F5U78p43RhtYcI59pKnsAQsLaLlNjF7AhIAmaWwwAhAazlw3lV44MPbWWpBITFefinfKxK+U3r7k3JgCQ501k2CtFUjui9SlFjBJCwpq1URebBNg0fJrmCoYXB5GCyUQOc/i8UNMma9yFuuyjhuYIqWmkDjaRgoMVPU6NZQeInDqE+O5Fn8gM5tzzDv3yO+/79/uwvgDhh4S/vCGvg5Pd0KTIQDjq8e9Zc+3g3bE3J82iMcftYxzdslz34oKdH13uVySyhsavT5lqirw5ZaLQwQQgYByFq770cxfdsrSKvGcn6v6oECnl4EBp5+O7duzes2rthqHRRUCktFZKA4BWSgjhuK5TdTzf9TxPSKEVASDjzDLNvG3Ztp3L24V8wc7lbNNG0r6QvlTMgOLAwODQ8Kp1G/fsl3dv3T711htHXn/15s0xQOSMzdEdyTy9GL5OEDOvmjZpVDdgmojGyM2GupkHdTHUuOqxCw+IUT0U6Njaz6l5YcIXq37WZ/XA2vXMooYuuY793v1s4ShVKshY2MeAkJGI1DTDGyMLbFTQGk07/+Je/+3z989Miij5sNSAkPXaGHlMDlHYfq55IZjihYSEJYQuP5BQSiggQobmSDG3ZHD02Q1iolo+fmX85bPlN6/KGZ8XLcReKBKChjNRm0rDKMGGfxXxQiKnrnHiIl5I4ARET3jz1DZXN3xNakI5LOaw6YJ3sGm1h4ZM8qa5lOqFQETlJ5wba8C8+vKtt3773J6/v8md9JFH72ZIFzUvZfOftbdpSWaBP/dj2/70468rQci7P8uIoHxdWGC+50c3IiJpQFZXtc3VxvDSRSzLYDyaCoPml372wpXXpwqjZk8co/unQjhnO3Zsf/6979+4dTuz8kKS4wkkDcA00czMzNitW3fv3JmcnKxWq1IKIA2InBucm9w0DNMwTcs0zZxl53J2IV8sDRQHivmBgZKdyyOA5/tC+MFZWrxs8YJlH976+JNvHXrt6y9/pTw9YxjGPGgRBAJg4UNFGBLkIYmEGHgH0DjoyQvdlheSvPAUOyuhs1T/trDvTU0vBFtJGGwpYzFiVEZfWmOpYD7zBAkZEZdJLwQTXkjj/jNGjmc/vtFYvUxdv42WGfYlsXeOyKxeCEa8kDD4SGFfsEMvJDzf5p7VtgiBpJZCAgDLGQte2Dz63MbKmbFbf3584uvnlSajYJHS7SvElD3C2J5EjBLAmhiiCDYLIXsm7v7WTnj92DeXJaRmMryQmP5tWEsISK2tmdjUUpxaiPpJzVM3+2knRdagefwzZ5fuWbDk8VFREcgx4oVgzAtp4JbN70KOoqIWbR188uMbXv65k7lhk7qW2gyFI9/z4xtH1xWdSZ/zxr5FUHEAiDtedXtIK8gPmae/cPeN376eHzEC/YFJg7cPVQgiSilfeP7AN/2Nv2UPLVJeRTlVQmTICZlTdS5dunTu3Jm7d+74nqeJOGOMMcMwTdMkAmAMCZQCYAyQAQoF4ApZrlRMg1u2NThQXDA6OlAqccY93yMi8hUhLli69D3f+OEly5d/4c//6ObYrXnRIhi3PptIccQLgRQvJIplpXghKRqrgVBBqheSlKnhX0Yvdrt2HnXkpjBGlaq5fw9ftYwcFxg2AzbJAARlokYAQEqzUj5/YNf0b/8l2BZE944S+qyXXkj8iyLWK4ZN99jKhz6H9WknlyD0gKg9EX4YQwAkTXLGA4TipqUbPrls6s2rN37njfLx67xoAUNo6Y5QZxPHMCYUnXI0WBVZLQyJ0aZCjXohEDH/63BTxsrHYP3ZJ4Lxv8SwJgxFthpBnTZUEwAylJ567VMnvulXnuEmI60xbBKFQkHhfQwZEoQAyNGdEjv/1urrr9+7+LXb9mA3WiR4yOYPLdnxHcvdKcE4ZuxdzAsJbYYmM8cmr7lf/HcXeD2+iD2FhXvyYqn6Qwixc+fj3/J/fE+uNCzcqgKmmBk4dcJzT75z4rWvv3Ll4oXKdFkKXyupldRaaaVV8JJKC6mlIiVJy+AnRERAUpMn5Pjk9KUr127cGCMA0zQQQXKGDLQQmti2Pfu+5aN/e/HiRVJKROz9pLEh3DDzyGNaRBhnvSBEIcMiBKBDlsKgyCdD/2/ryqSEOlp8nCLHtjEbQsOwnttL8YlgaHwhNYhxE5BCZhd5fm7fDrZoBKIODUXH0PtzT1EgP4p9UPpSUurwElscWjNKWMypXgJDZKgdISve0OMrt/ybb1v1fc+QIvIkMjb3KFBytEmMk5LQTzKORJSi4gmytUXkfFL8udTVTaSUdcTsObe8F6TJLBp3T04e+fVTZsEgnYCWIg/DaOCsPj0EANCKDvyzLaXFOeVr6FAIIYLy9ODy3POfWK98nephYgukvb7KyOBLP3th6oZr2Iwo5fr0gxfCkvpDKT1QKn3Tt3xrfmDY9wUiQwIgTUSIbKo8/c7bb09Pl0kTadJKax1oCRXoENJaK6UU6eC3KvLSWpHWSikh9Z3xycnyFENGRKymfBFQS+GuXL913/5nLMvs2gvB0J/k3QqdJco4shgXUBSWp+F7RjEcN3QLwg5IJKML4uF0CIXT0yVZWEpm6Y8WVi0lFEkNIHM9vnGNsWkduF7NBQkQubSVqcEK4SljFDEXii0azu/bTp4PiN1b2XMAsqKqHCENhIwb0nGzNAQnhsE/zLz7TTmNTYWKjMmqr4Va8bef2vxTH7YWFFXVQ866PNAQg9SaPkfjdCamjNnqEmOaFtLC6aHTH/cYMMW37GTTouH0iGKjSNwyKXFbGXGSckPWqT+4fPHLN+xBU0fwQ4o+LI4rNDeSoXTU0OrC/h/epDzVsSGLKH39/D/ZMLQyLz2NLCWSSummTG11taL8sPnGZ2+c/vLd/FB6CKRPoiIpp1lKsX3Hjsc2bPF9wRgLIqaNyZumKZUUQhAREQUKRNdeKvhb49/NFzX/qpQKVkAoUXUcTURRY5yAK6WWP7Zh2dKlSqnuHBHKMnjDwqERoqYEvhqPCGD0xmECHE+9RJTtv2OWxxPGOzH6Q8yeaRfQFtYi5WQd2AumGZzqcCgzfeSx0UdvPyCAL3MHdmMpD7WN7gk61dFbMaTKY4Y1ZT4emwuMYaVEKTZ9SwM0HGkhZAiIcsoZ2rVyy7/9SGHdIjXjIe+Jb43J04lhxytVT2YccgSErN9j7OjhHEUZhneJojcodCkxW2njbMedmez1X3x7+kbVsHlTfBHGo3IRCC2S94sGumWx+cPLN3/rCq8cRaJai1SO7pTY/m3LNn/zEndKMIZRDDiJSGHMCyFF9oBx5Y2pV371Sm7A0LrvQuitVAgRWaa5dft2w8pjM3u6Nkml5PDw8LP79+dytuNUlVK17dGBOqGEvojqkfpLSukLkbfzw4NDSimM3nZNSniup43RBQvZHFKzMuFTTDXzY1ZswvShNoQzxYCsUMB9ts8TJdyfsOGJnQrX9CFGlhqRfJ+tWGLs2gquGw4hRz9M1CrQG1WAiOQLc/USe9dmcn3oCrehrj5DLf01wqQGoCjQiOFdiM4PIcs/Tbfi41uInMlp1140sOVff7i4abGq+Miw60WJnzFqsWKZlydwXDDpxFJrs4SSX5qEYNv3R6hVfI9md7TTh0jcZjM3nYO/+A4zWJZLhnWjB5NLiDUDS7pq/w9tHF5TFI5qx5RFBOGqkTWFZ394nQw+gjFPN8ViDE0UiYAZ6JXlF/7tOeVrZAh9rUGiKgQRNVEuZ48uWESkGWcYkuCIGOiSLdt3fMdH/+aWbds5557nua4rhNBSUQA91kpDiBoSlShAsYQQQgqlpGXy5UsWrVm90rZMXQ95NT4hhJgul2emywMDJdMwOtUgYfwqxceOJstiJJExDs9QpkyKgAYUXsEEnIsxIItiKiaZkRVGmkLXk6Dr3ILwmlBE3Etz/x4cKJHSwTswBexpmmoNxZoK+TU9NYL883vANIDm+finAVkURxobig6ju4wxoJHq1TkRICuuMjBVYmPiMESHQWhw7fhGKbfpJ74xt3xYuaIzLRIDPzE0MoQ0dymOO8WWDGtxLYKYx4tNSyPt/COmAJhxb5za27RwRlYa0IUNE6ZTIyPIzrr05Zsn/+CSPVSPhxNFnXxq1tgkzkyQPaGELi60n/uRze3KcURS8MI/21BaZCufmshwfRIYxbFj4CcBkQaraHztFy/eOjnTh1UgyZeR1OAG5wjo+R4yZloWU0pKqbVuSEilaeWq1cuWrxi7efPyxQvXr18fHx93PZeIhBBKSSklctNU0rQsRDSRMcMwOCuViqXSwPDI4PDAgG2aRKS1QkQiIEACpTW5jjc1NXHr9lh1etIyDYNzIWX7Zg3O+kOMpY40bG+ktNyqWsJkPGyYkf2SBnTE00kwXKMQ94ogVkgVzp9BaMsOyob8KeaGSclGh8x9u8jzG2edInWQ8fTKSP1jlnxAJNeztzxmbVrtn7yI2WWGPcRyoj8LbxBFb2n6LtcHHslWqin9lCm3SISJhQowYvJypl1pLSxu+JH3n/ypPyOpYE42ZiNvL6gQjIVAonuHEJOVEAVwm3WXFE9+hZS6qDisj50ATS0zsjCK5tarbikG3bVhXWgyi/zwr59e8vjo6IYB4UjGZy3ApdjYkKFXlmteWLzzO1cf/a1L+eFWlRlBIfru71m1/hsWu1OC8VhxcLgSIP04aQWFYePEn9469ntj+SFTS4K+Sd5tW4UEsSApXcfhBi/kCznLUJz5UgaBDiJCgADCWr5ixarVqwNHZHq6XC6XXdfzfV8pjcg456Zt2baVt6xCoVAsFg3D4IYJiKQk6ZpcCaSSJhJCViuVyYnJ8Xu3J+/dNhGNWavpur58kcK/1HqltAx3ahVQbdgaodLCkM2B6ZhZ0xCrlxbGoJY2wLRZDb2I814bAmPkuObzT7HFC2mmAgEnDSUkJiW9DooBuRQ364iI0DQKLzzhv3PhPh1kSktLipl9mLb2iVVKRImpKSgxUWkYeVOLUAnVMrw5qoo3sHXpqu/dd/FXXzJKdrs4LaWMmyK5uZgCgMYKRTC5ZAmtEymITRpGFP32sDSkzs5p7fOxfaNQtnx0N6jjI8EMJmbkq5868Y2/9DTjNTKV0BQo7QjEZ4AM/Ip46gfW3zgyfvf0tFk0UnN8kYHvqEWbS8/8g3WiqpDN7lFiQudZBXb3fPUr/+GCYUcA/H7WIkYqkqiV9D2PPAKiQqFgWZZlWUopKaSQQmlSWiOiVFIIyRiWSqVSqbRs+XKGQfgdGYMgOkJASAREuhZ+r4VPEJEBBIH3oMR9enqmPDkxOXGvMj2DwrMKtmRIc9AhlGry1GCFqJGYFJTRRHhqEpBAIjKbqLOLsW9BguCEohxcFDHww/gwZsL9rS9mptff/K3WkM8Zz+6NlBM2o7EUtl6jtfQI0YIVxIStiowcz961yVi1VN64E5QZ3jcgq4FbNWRcVBO3lZEViguFC0xh1oystHK8CF6BnMuyu/Qbt0++cXni0BWjaLUFVrTKyCLMJN1Jc0vS5FLUQYm5pMnSQoKUZGFsX3fUjA+Msn2Enb8YwQnNcsgz4aySMXbk3rFPn933w1vdSR8Ngth3Rd19SlTMAKKW2ioZz39yy5/+o8NaEaZNNLgwL3xyU27I8KZrHg/FGWYg6mNFwiHIkDR88WfOVcdFbiBeSPjweCEBKZb0tZKeEFJK3/cLxWIhl8vZNsvbSkqhtZBKCilVPXKuJADoJrUcBpXqgUKqReNrcYLa+ivSSirf81zXqVaq5elyeWqqMl32PQeVtjgyzpBh+35+clsx3UmgZupcGGKOZdZRw7sPK5QalU7oEFBLVCdZVBwOJkQVRZ0tB1PwdkpGa9qTqykV6QQAjEHVMfbu5I+thEY5YTz8kfRkksIrrmubyIPSOFDIH3i8/N8/j4kyw3kFsupClcIyLsSRhcl6nXS5j6G83jjJJrQPZCWleLAaq75nX/mdMVJdmUkRLBSj1ZQpYod0PJJGmMh1To1lJMRfqMQSotXj9cwapVuf06bxQfFgW8M3ii8gZqe+tHxpRdag+dZ/v7DsiQUrn1noTwcl6/Vz0OTIipWjRhaHcfSn5Yq9o3v/r7Wv/tLZ3EicPpIZ6IyLpz722GPPLqhzq0QYV6O7j02tXK921IoKo8bL//nyxVcmCqOmlhT3gh8OFVKPhGutiJSWyquzYFXsXKGQLxYK+bxdsi3GGGiUUgpSSkkltdZa6ho6pbXW1IylB7m/wV+E0lIIKXzP81zPd6oVp1KpzszMVKfdaoWUYkCcMUTAms9J7d+pVOcjFLtA4AwYB8YoVn8Rv0KxuxE2unUrGdaSI4sAkHOIcDsmSmRZlHIugkcgMg6dpDhTlglDBJyZzz0Zz1QmwhQqiViwJ5GEhmnxSYbg+fmnd1Q/f1BXHOBsfkPrKRxZSegS47xjjCHnIVJkDHGmAmBdqQfJIbqWIwIs5QtaAFkJwIaAMeX4pU1LFr64cexzJ8wBe3ZHJBktC3kJmGmj14x8bhvcNgLDLsa7HCeGifEZQ6w0M1bDn8LUaw1YzGKzyzzMACAx29no6gQFM37tP7394c3PWAVDK91kGYhwZGWy8BAFhIliz99Zc/2NiWtvjFsDTTgLGfozcunjg099bK03I5AhppkbTb2FMcOSSFFu0LjwysRr//VqbsjoQyKsdlVIg0eNSJOmIFdKaimldB13Zmbasq2cnSvYuXw+Z9mGwQ2GgJwz5EpJrkgCaq2CfCwlaxWHQikhhJRSCOELKXzf91zPcz3XcV3Xqzqe6yjpE2kDa1TWwSXVSusO5U5q3WY9eizQcdANxFnj4kWSaKNZ4tEslSC+bFkNR6RTjiwkDY4bQp8JIpUWFB9xmGMEAbQmhtBJckGmoex5bN1jfMt6cL0I4SomIL32ObJCSEhtukLyRSO5fdsqf/l1LBXmRYXMhSOLofalrroYLk9IMoQzYAZHk/OcyWwDgLQnSUhEiNMvxYGseg5C3I+pceyQkMu+efu9l8+RbKP+OV6OmuDIggRHVs2oIW6yqVN3ymfvcYsRxVcpla4mhgrGwulJ9yUcK+E2n75cZmamFpknjqwWcXWjwCcuTL/xyydf+KldaloBD+5wCkdWIs4UAu80IWPPfXLzH//AIekp5HW2O03c4i/86CYzz0VVNgpBoq4MRZJ6w1C1Bm6yyj3xpZ85X8uM0LG80YctnK5JK6kCNyAwuzQREPhSCt+vzlQnOOOcGwbnnGGdMpk0EWlVKy6s16sH2VyKlFJSBnpECuErKXzfF8IXvq+Fr5QC0lhzPRgiBT6IL6XSGroqLYx8Rmuw87nXX7aOH4oU0M3iFCc5TtD7+z9ICxeBECEOnzY4sojANODeJPt//isIkTajEDt183ylDAAcB3J2OzlOmc4vIiltHdiLtl1vDZLy4S44sqJvJkAgIfPP7aq+dBSUnpfMiK45srRmhdzM0dPXf+3zLG8lqauaD2aIlsEMbgzmc6sXFNYtKm1fYS8bBqWV6ycIS1KALApR+jeCcIigXFlYu2B4z8q7L503SlZn6Zttc2SRJpYzbr965ex/PWQO5UjNpyKvHXkwcgbPZSakzp0jq9OjRJLsQevMn19b9uTCTd+y0pvykWMWR1b6VxAgQ1FVizYPPP2D67/60yeDXGHG0Jnwn/nhDSv3jjgTghlI6SOMMbM1s+mIwMyxz/+bs/fOV5IZX/3vjxhJp08IOT09HbCa1Es9avCW1gCoSejALq3rC6V0zWvRWukACNNKh3+otZIqKE3XUmrSSkklJUlJWmEde9BEWL9lHNFzPa00zu1U11t0IDhVVp3pAk4NH6J6xXWWGRQDsmJ4tIaJCfB96Jr4iwgYh+x6ApzVRkMEX/Bli43d26nhgsQI7yHkecSCjZjCuETpifYAyMgT5mPL7F0b3FdPYDE/j9m9IUAkjSOLUpecpFYzLmkNmrI1UlCER+61e9PHrwCiOVoc2Llq8bftKW5coioeYmO9WmZkYaR6vPGLhc9vuPvK+Y7EdDJ/LJUjK1ziwm3DGs6baT2g5mU3dHu5HxiKlcbcudhCzZ0sn8Cw+eu/dHLx9qGBFQXlqhrvCGVlSEXtO6wFRdwpseOjK6+9Pn7ui7fyo5Y7JVbtG937dx9zy5LxKESX+dAGEglaQX7EOPY7N97+s7HcQ6g/slSIuHb16pbH9+r6HlOjckLrem6V1pqUUtSgvtJSKwo0iNKKoJYBXPuv0lopIlJaE2mtZfAoqMdLGrF2hkRIwEyl1L1795TWBmdzgUBCJIAMkM9JSiELl4m3kZGVcP8NA7r1q8KR2Fkt8uw3Ifm+8fRuHBqgmSpylmAobKjcNGrQevSPoqyiKUBW6JOF5/e4b5y8b0BWw6lLuiMQutu1T3GGnLXkQMZGzDd4mqr64187OfXGhSXfsXfpR58kT4bZl1tlZFEDCQySGlB7srRlSW7xgD9RRYPN0lOsJUcWpntg9bQIIlKaFFEf4Oyzt5yCEOV+LHWgcyCrcSSYxZxx79Wff+dDn3qynleY2kcudqnjhWVK0oFPbLr19lT1rm8PGM9/chMzUPm6EUVv7gKlcrPWpkyarCK/9c7MS79w0So8BFWEqa90pt6zZ8+OXbtiGlxTMzjZCI8DEek6n0nz/0SkCUlDEEqnCOdJXZ1A8OZAj9Q/2Ng5BjrwRSzGJu+NX7t5s8eFIYHSmsufFJHdLkcW9XoAqf4HtfaxlGLDg+a+PeQLSGF/y+LIqnUECZK1W6J90W9mSK5nb11rbVpNrg+s12BWtxxZcbaCWf4QEEHtrBNyNAbyAHD9M6/c/B8HWd6qZ31QlCMLEoxMEamEAFpqa6RQ2rhId8Hl1yZHFvad0Jl3jqys26/IGjCvvnL7rd++aA9apFJsPExdtnBWC6Jy1dDK/HOf2OxOin3fv27JjiG/osJciuEIXAIDrptmBIyj8vWXfvqsNy25weCh1CBpHFmGYdy9N/7VL39+6vZ1k2OgHOJvqv+QaiqFiMKJp7UfQ42WI/QCYgnvFBE5Aqsf+5xh+u7UqbOnpysOY0iUZhN2J1tavg27eVR7HFlzOPftW3azn0DGyPX47u1s6aK0kAxlcmQRYc6Wpy6I81chZwWZewCRuxEyIJsLELQ9QMvIP7+btJ7HNeiGI2sO36U0IJrDhZu/c/Del9/mpRwo3bJkJFYW0GSaQs6KGxfPnnnYa46svnjND0dWa4TNGjCPfvrczaPjVsnQKoMjq9UlB+ToTcs1zy/8xn+/c8u3LPNrVSAQSrSEWLIMxDmyKOjT/vVfu3T10JRd6ncuxc68ECJijJ07f+Hzf/G56xfOciBijEgB1HLLNWCDJJ3qbFhN1Lguz4iaZRAYjqjUPZRg7xgQAwLSBMgYtw1jZmr8+Im3b966wzLKgNussGtHGVBILVEHj+qQI+tBYQWxl9ZoW+aBJ0mp9EKaDI4sIADO3K++7r18GA0jmmpNLYAsAkDGtOvn92w2Vy4mT/TYKp4TR9ZcPVoiYLZx8/cOiXszaPLmiU8ZRrjOBkPNXYk0FVaNMHM2tLZrjqz+E033gSOrFRrNUfrq6//xbb8iucFIZ3JkJeVGpMGIom0fWc7NRhk5NQpa4xsW0uXB3mlFuUHzzJfuHvrstfzDlsU7uwqpG6z83PkLn/uzPz366kvOxB3GDSJGpElLIEIgRCIKGkk1kCtoapQgNRhAE2kV8mMQGogMaY3ICFBrYsgsg4Hyrl+/fPT4Wzdv323h12NvBWs3D8/weanLL70vW83I9fjWDXztaqg386AsGYQU1vtomermHXHmkjh9Ud+dAMOEtiIy9X9IxQaLhQOPk+i1CmnFkRWNXTeL/3s3ACJmm96NiYmvn+N5i6glkJWYeMAFS1Lbiwd4zuw816BZ4JLAfDBFw/cbkJWOGiHEKPcjNZQ9cOhJkVUw7rw9eejXz5hFo6kA4u3iZ7/7fkWFq0+Ta53c/iAEYti8fNP9ys+dQ86g/zaoNyokQLQmJie/+tW/+ss/+aMTb3y9Mj5GShBjwJgG1DrKMFlPv2p4JRTt8FLTG3V1A0HcXWsAsk2GJO/eHnvrxIl3Tp2tOq7Rsi1PO0VL2InkoTRSqS4em+haiPONX3VogKF54ClgSJFev6mmVyicrgkt0z/8NlVcPVH2jp3CnNUssURoAWTVTxmS5+f37zBGh0CqeYHnM5GIODVqjxkjiJCx8vGrujavlq5siKS5eS+0Noo2L9qkW2q3Vl0LY2QGUTilbw1cSh1fuLdb+21aOntpRfag9c7vXb7w5bFcra8tZnRoi6CBkZUP6tcghlulnf/Eixv4lZ87V77mmDYjDQ/1y0i5cCEtwjknostXr924ObZk8aJVq1cvXbFycGShZReIcaWU1kJKFSTxBu0IA1ekFmcnTYpAayJFWpHWqDUoxYAYaORIHNyqc+vO+N17k+MTk1JKxljA3dtbGKfVAenmsRQ21GfnyHrg7ggieD5fs5Jv30SuhzUSOKQYe0SSI4sAOKOq679+AgwOpP3XjuefewIaNHJpHFkJnjwkX/LFo7mnts58/jXWwzLDbjmyeiWRiABN7l65J8uOkbdI6RRGg8YBxGiIOBiIJp43jKLlj1ewBZ7aNUdW/yFZ940jq/UoGMfX/tPJRVsH86OW9mu9BVM4stKArHoVarj5fMyrj3NkUS2Bggqjxhv/79UzX7zTmvf3YVUhlPBFAMAwDE107cbNG2NjOfvY0qVLt23dmisOBb1wtda1QCxB4FVAQAbRSOfVigLGE62DBrpSSs91lRSmZU/cu3P2wiUC4IwFGmte4dcsd6RNBUPxC90hR9aDUyEklfHsXszn6ry8MQQrJqwayaAa8znx5ml55QbmLCCQF66JC9fMTavB8YFhKkdWypQZkFSF53dVXz7Wy+qQbjmyqIcni6Fyhar4RjEHoTKmVhxZYaYpAjQ4szh0FFBtnyOr/2TU/eTIaqH7eY6Xr1df+8VT7/+Z3crXMWpqbIXOUlhFN5V3hPk4ggdDPbXELhnXj5S//iuXHuoQeisVkgVqBYoEACpVT0rJGZuanHCqM402t8GbgkWh2r81BuUhWjdqE6WUnue7nqekMixryaLFVcchAJPzlNSv+wLIzu2WtceR9YCvLIIQbPECY89Ocj1gLF11JDmy6kaVf/B4LeMIgTzfO3jc2rqW6gTm6RxZ8UbCCJ5vrlluP77BPfh278sMO+TIwt59LzLUrtBVHzPSMlM4sgIVXe/igQYPqtwj5JatXeD2ObL6Fmq/XxxZmVunyB4yz3/h5vK9ozv+9mPupM84pun7FNYTSnazrJ+7MMdMaG5IRMxAvyK//NNnpKfNh7YQpBsV0ngppRYuGNn9xBO5wqCny4YlfM9XKuAskUpJVcO0VJBzVcO0gliJ0kopIbRSChmz87mBgeF8zrrjiwcO2XZOhBnWFG1wZD1oFUKebz61G0eHYaZSa6WJafBelCOLgNA01dgd8fbZRvwDc5Z/7LS6O8kGCkFgI50jK65AayXixRd2u4dOzSuQ1S5HVg+1iMGQs4gVOytHVngHiGY//11zZEG/Aln3iyOr1Ug0mQXjjV87s3T3yMjaknRko619amkhJoBQilVxRjphRuBT0mQNml/6v8+MnZjOjzwKEFYdX+jA9SMA2LhpU2F4kSOImTkjVzLzBdPOW3betGzTsi3LNm3btGzDMBgzCFFq8oVyHOG6wvMlAZi2nS8OFIuDIwNF16lOlMuMsQeevt46VI6ZyDS2LN7CB5XUG9P8bKBk7H8i4FYhTHbKyJiyJrRNceRtPTkNAaMtARiGvjfhv3m6TuHeimI/zL6HDMn17W1rrQ0ryfV7E1THLAkVz67BUO/H3p4bImK2wQo1kqtkRhY1lBiFA+ANMYmkdMC02MEtiNdHUkdZgn0BZGXV8YUpgyMto3uTkRWHIU30puXXP3WSFGGoCg3bwy8wkXWVmjZOinLD5snP3Tr2u9dzw4+O/uhYheRy9pKVq81cATgjZMzKGbmiVSgZuaKZK3ArT9xUwKQmX2pfSM+XvtRaEyIalpUrlIoDg6XB4aGhwQUjQ8Wccf3GTd+XDB/YIe7UbmoDYg0nZPRBOD3I5d21jS1fCr6oWcPNVuhRFhOKInKcUcXxXz8R6YJOBJx7rx2nWGZwi4ysRrW41mibxRd30xxZXlKBrCzpGiUr7/lRIqnMkaIxmKdWVJIUak0fHQ6i9qVy5Syt1FtlZKVzZDW/N9gChvP6p2sFnHI1MXvOPXeJFNkl49rBu0c/c94ebHRZT97q6MpjXJAksv6aKfKkycjziYvVr/7Hc4bN4NF6dQZkMUQ7lx8YHAE0XLfqVKs+oiIARUQIxFAjR07MQENzrSxqFiAiImPc4MwyrULeHikVSEvbthBnQZI6RZnaeT/1DMiCzjiyHgBqQGiZxoGn6rEHJGxUBCOmSN+Gyawhn5PHTsmrNyM9o4jQMuWFq/L8NXPzY+R6jQqeTCCr0ZwemXb93J7N5opF8vYEhjVT74Cs2p60w5E1dwXCkIQqblpqFG057TTaGUEbHFkBOxRyphypKl6t93AbbkfHHFkIWmhZFWiw+eLIQuQ272zT7jNHVvZLK7IHzWP/7eLyJ0aXP7nAn/EZx1mArGieFUCEVjW8C43A1Vd+9mzljp8bNB4lF6QzFYKIruvdvXl9+ar1w8MjhCOghedJ3/M8z/F9X/pCiqCfYY3XXUmphNBKaC0ZAWfIOZqGYTCmNbgKFiwYnZic9H3RopCQupUq8/mRGGiQ5f0+aC+EMXJcvm0jX/8YeV4tZps5qNChr//Ie+0YKB2P8zJGVdd7/bi5bV0aR1ZCazZVDIFUbLhUeHbn1O9+uQcNcTM5ssISFqL9R7GX9XaamG0MP72OlIolF6X0hcVInigRIAEy9CeqsuLXYlRdGEtNVgEKcWTVk00RSFF+cWnk8aVG0Wzmfc0mhpOSMVsygJZ6+nK5zfhwnCMLozmNGDNEqFccWa2FGyn9yn84+ZHf2GfkmJYUYfFPZmRhqAt0s7sBJiIlQJJyI+arv3bx4iv38iOmlo+U/uhYhSitjx87NjIysnjlWjRtwzBKRRtLRa2VlFL4wnNd13Ud1/Fcx/c830MFmhiRZqAVkSalpfbIMBxfTlcdy84Nlkp37o0nubBi57i3Xgj07IGxQCDVMhIx3Hc61uxg3jG6qLlG5oF9YBp1kvkW2csUyqkiNE19ox5Ij2VPEaFtecdOF+5OsIEi1KRndkZWuGqbIXmi8MyOmS++QY4LnPcmtB7J7ElJ8wkl9fZuqQ0mJ52R5zcN7lqtqh6y9JOSIHhvWtakAQ3m3pzSnjCKLXsXphUlNZ28zAhP0CFRLP/ghhXftCkqqSNBsWjUrql+ou4OxLRgcGaYxdw71a9+/POiKmqNmDrYtRaNhOMN4OcRztJkFvj42emDv3zmxX+1wy+L1EtO0S7VCVQu7A1TDSUbNC6/Ov76b162Bx41/6NjFUJEnLO79+699NW/OvCcyA2MIuPAGRBqrZRWWiophJC+8H0lhBS+FlIrpaQIuoNorRkyxpn0RNV1CVjeHjQtkyizPfB9cSm6eCCFk/FDjNExICsjw3RegauwNecJtmo537GZHLeOk4SbZyRKOppJPgSW6R95m8ozWComVQiYhr436R87nXv/01QRQa1iy4ysUJjFF8bSBfmntsx84fW5lhlmcGRholsDJtGQOeoPzlTVtxYPLP/u/VqqkGsRz8iqN0KksFOGDUpOxMr5u7Pb721zZMUysrAuy0hKjLaxqeuJlE6dGY01IcasW8sQINK+6mLT2s3ISlyi+chy1IrsIfPkH19d/uTopm9e7k35jGMmkBUxXRrjjeo9IsNm7qT4q589Q0TI2KORxdu9Cmk4n5ZlWZbtVCozlekG2ztpUqS0khQ0lmq8tA6SQYM6fknad5UvBHBeKBZMw9DzSuA6Xy5LBpCVdrTvf1Jvg0KbhLD278VigWYqyFmE7SNaWNAIEFBdPlK1Kt54C80MrIkIOHcPHs89/wQimwXIakr4eptyqYrP766+/OZcq0NacWRRaIoU4sgCnFMhECJDUlqWHWvRwLqf+HBu5Yiu+MAxVmcaB7ISCgwBgKFyxMyZ28zgnWvSZuc7RMwqY6QmV03Deoj49vWWT6GyxBhVfDwdAWupwpGMN+xi09K6FmJEdQWT6ilHVmszmdv81V88vWTHUGlprt6WqjVU2zCbMFpGHxw5/Mq/O3PvQvXRC4E0Ue3OgCylhgcHD7znGxYsX1McHi0NDpuWBQyFFK7veK7jua7nup7n+r4npdBaBW1zlSIhlev5FdcTSnHTzhcGSsUigqxWHWT4oEipqednEB48R1bNUJSSLRrle3eR5wNjaZ2yKZ0jS2u0LXnygrw2BlamCkHbEueviQtXIVdrHJuZkQXRxBtE7fnWuuW5net1UOrYEyArW85mcmQhBi2nZvnDGAZ1+ETaE7LsANHCD+3c/DN/s7B+sar4wGclxE3hyAqygZ1rk5XL95g9W2ZB1xxZ0aBFnMSw2eoR45GKCNt0ouIUe3P3HghHVovbyy1WveO9/HMnSTd9nyyOrFj5YXLRtaLKbQ8ftSSsOXghRLRj1+5VG7Y6jpfLFxk37ELJ9Rzh+0J4ypfS96UUQoiGK6Kl0qQVAHHgjFvctEyDMcYQ8ybcvnF7ZqbC+pGRetbj398cWYjkesZ7nsWFI3UXpCnM45k8ISuvYbH7B99MCaTHBJIQ3mtvWVvX1VKusoAsTDAIERBA8cXdzpHTPQeyGnb0LBxZCCSknKoyIWchF2EIQUJh0covHxncu2b46Q3F9Yu0VNqpJePWU61adi2McmQRATP5xOErcsYzB3KzoBxdc2Ql3ZI0azpMeB5vPIuRAjpMeAldbtoD5shqJeXyIxYiAug0+t52ObKIyLTwfT+55ff+/hG/qriBRH9dVUiwXFrrfM5evW6TYdrck/nCoJUnKby88KUQvu9J4QvhSymkVFJKKZVWmkgTAiJjnAOAVkoKn6RXMA3lV26O3dbU7GWH8LB07up7jiylsFQ09u8FIREzWawxYVwREFqGunFbvHM+JZAeuWoaLct7MxZUTwOymsmsdUkUlBluX2etX+Gfvx5JGp4zkFUXqq04sgCRhMqtWrj077wIJg9f7pjuR44sZzGbmyNFe+mwtbBkFG0tlaz6iIAcG01xYpjM7BxZHOW0d++V88zk3YjhNjmy4kI3pGwwrA9STP5kJ5iIk4ld2kX9wJGVPjCGsqoWbBg48MktARVD2ve1yZFFiOBX1MKNxec/sf7z/+oUHzCA/rrGQkLIKHLQnPNcIa+UVkqZJrN1jmrtbaWStXxeoUhJAQBBd1ulpPQ9z3V84SL5tomlvCmMQrGUr1SrDWreh3CB+5IjizGqVI2nn2CrlpPjhBKmY4GBZMspCqjdxeETVJ5OCaTHjkUQVD96Ov/B/TRTpTpyTNnELs2fasKCVXxht3fmKiLOvUCkI44sQCRf2qsXLtm0rKE2IlHiprgIcDAiIpCKpBLTLiLU5hoRvC2mHOfIAq35gH3nK6crF+4aRWv2QGvXHFmZBzfmn2EIoWpxausUznPPb3vQHFlpRhExA5//8W32gOnPCJYgO+mEI6tmfziTYvtHll0/PPXWH954N6mXOa536fzpZY+t52betpjBgTGmSZMmpZTSpIgCLSKk9H3P9zzXdV1H+E7VdWak53BSOUQOIKR0FSxavGRqctoXAvHharzS3xxZRGga/MBTNbmMEaQidPoTOb4EwJieqfqHToDZTtEGAePuwbdyLz4RJctKiqJ4ynzQVj2/d7P5uVfl3ckuywznwpGFSEJJT6RkHNXVDkaiCLVSBsZZJLQSYeOgNjiyAICAo6r6N//srQYpUxsCtzuOrNiCRGAirC9Ic1lC/k0aKIdzTzXsH46syAJzdCf9/f948/KnRt0JnxkpLEAdc2QhAKJw1POfWHfzRHniUtXM80csL6ujcDoAwNEjR996/eXynRvTU+VqZcbzXNIaEThnnANqJX3XcyqV8lR5Ynzq3u2pu7em7405k3dldZqE5/ue67ieLyfKlfHJsmUXiqUCPXz+XR9zZDEGrsfWr+Wb1pHrQS1XJ4S0tODIqvdIV9fG0GoDXNKEOUtevCbOXcNcYEpncmQ15FwTCpeKDw8UDuwgv9tuhnPkyEJEzqAeME8G0iH4LWfAEAIaD2xNXIhtcGQhKW0U7VtfODl9aoznzG5kSvscWXFcMRJOD0H57YfT54oldc+RNW9AFnL0ymLN84t3f+9aryxDlL2tz9wsHFkEgAyUoPyw+b5/vokZOEtjsUfbCwk6UM1Uqy9/7auGwUojiwABuYWMBT2jSSkpfF/UytSF70vhSSGU8KWSpLTWCpAhMyq+43qeado8ZxucB7AsPQpAYQzIiplyHdwxmtMgtHHgSTBN8IOKjYSrAVF6hkgNNYo3jgMicAZ6tksUNKRyPe+Nt+0d6wm8aFAXky5CzBHRfr3M0BXA55BtGwJE0jiyUjnPKR43TmQ7h35WR8BDRcgpaFU8cwljKAcCkNY8b1Uv37v+u0fq7XLbNN0zR5vKkRXPaU4CL5SG8ietfEwCWREfYi7KhIhSEIgkWy7Nj+qof53ydWlx7sCPbqNAlrFICkZjzs2Vx3iqMyYhusYx5+hNq9X7h/d//2Mv/8KF/OgjBWcZXXxmydKlwyMLqp4zXZ6WQmnSRBoAtdZaSa2DQkOplKo1C9FNR1Vp6UpXApqGaReKnHMlVevU676MsbeZkdXlse9+vojg+2z5Mv74NnC9IJc3Km4ipYUYzr/VBLYlz1/xX3sTtKIp2a4UUNp56XDhA0/zRSMgZDjvKFo+nTQmkXxhLltYeHLL9JcOsVIBOu0CmpWRFa7pi5GwpzCCxeGaZsfGRBVFNqdKJpAVRjmICDkjoS78ytdE2TEKVrsuSLLVfYQjK2avJEZLaUsWz8iiLBGeAmSl5Rx2DGSlcGRlA1nzxpGFiMqXz3xi59DqojflMwOzdGiEIyt+ZmInPELNghy8snzy+1ZfPzJ18X+PP0plIp0RnEipRheMPPfeDwyOLIbyOKHpVB3Prfq+q5QgoZTSREprFfRQD/qlE5EmkpqU1gSIpl3M5Ww7l7NMWZ6oOE5rF6QvVzqjtDBL28ynCZUilPc/AaUSVCrAWEKTZZcWBtagUrkPv6fGXoUhots0Fo1mzZoQ5Pkt0A7M8sQQSKnCC7srr7zVTZnh7BlZsQyCVjZJPCkZ07ox4qw6PLW0kBrp0Txvnf+FL08dv24O5uZGeth8OAJmZ38l1WUKpVujHjMcWcnIyJqrw9xxaWGyEKaHuC9Hd9Lf8Z1rNnxouTfl10JTCLN0LUw9M4RJBrqmmtcEAN/wzzf+zt876k7LRybHt1MvRG/dtn3J6nXVqsgXSshMnnMsryh8TwakJlJIKZQQohZe11qTZhoQDWbkTMu0LNMyGQApyZR7fey663osUVz20K5tDMjqKaNfOy6IlDg6zJ/cXWfEgnCWJMQlY72eoMGN6vvG2lXm1vVAhCH0AyM2byzOHKTJI7ke+TJkVFI0FNLEKyIrg4w8Ya1fkdu5rnr4NCvkuqxXz+SJihfkdwtkUdPNwOy0K8hOgNIECEbRvvJbr93+4klzoEP9kWaDRxt9Y5p9E3VLMLlklKYjo4RDlBbUao+BcTZPPrlvFMpMTmRj9PouIUe/KhdtG973DzeJqgQWPqQp4F1k7pg4Qhh36cKuFTIQjhpZU3jxkxv+4ife4SaHv24qJIiFLFm2ipu2aWjEkmGV8kVfSeG5vvB9IT0lpQhKQpSSSgY1IcCQc5NxjoxpJYTrSqeS4wjApqtOFj1Wf9eI9GVpYVBO+NzTuHghVSoBL2/Q0ygsS2qlhQhppYWBP+E1comwec/D3SkalA41/RNwdSC2XVoYRl2IkGHxxd3OkTMdJ2V1W1rYIZAVstA7ALJCYLrWaHBu80u/+crNPzrGS3bHIfQ5lhYGO1/L4wq9s0Z0GGJYj+R31croiCiVM792/IM/nW7aAy8tRNCSDJs/9+PbzKIhKhJ5Q1tEzkx3pYXR7EegwOOZEts+vPja4clj//P6o5Hj23F1uudUGIKdMw1tKK21NkhToUhKK1JSBtUiSilNWisi0pqIgpbpruc4olqWvm8iFSzTlcbixQunZ2aIHhb8Knmh+6m0UGss5Pn+J0FKCDEpRglEW5YWBg4F57V6iOavWZRfL+yRpEDAyefHSwujZYba8XI71lrrl/sXbnRWZth1aWGKKMJahgFmtqpNC7pkAlmNFumgNS9ayvHP/+JX73zxlDFg9yCts8PSQuSIjNdrX6IxFUwIQUxoqegu11zNOqkzMxkzeWeXBx58aSEy9MvimR/ZunT3iDvpB7naKSccuistbG5M+GAgA6+qnv8n626+Vb57pvIIdFDvkOxd0ZlTb2/Yui0/MGpblmlxjoyAglUIkq60UlIqJbTnu47rOtWq57nVyrRXrUrfQS0M0gjMcdWkpwaHRgaKd6bK04w9pDwyfVNayBhUHf7E4+yxleS6wFJ112ylhZTIXIq1c0gxCClU05dB9p5iP0YtZa2xkCu9sOve2Wtdlhl2WloYfWPNoAQMsYZhHMVIIDmzAVlISqPJjMH89Ikbl/7L1yrn73SvP+ZSWshQTPtyxq+TNcXYdhur0eyqEq5kb9APheqLCMJk7wbzJtyOjb4HWloYZPGufd+Snd+5xptqVhGmWkJdlRbGK1pq9guiFmSX+Pv/xcbf+/hxUg99jm8nXggRZ/zy5csHX/ry47v3WaVR0+KWZRqGyRkDRE1aSum6nuM6rus6lYrnVD3XFb4nPFcJj4KWIaSRGVXP96QeLhWLhcLkVPlhS+rtr9JCDPApxtiBfRClM4me/tlKCzHBW4HQLEhOY4KKBpBbkL0nSgvDwoshuX7+yS3m516V98odlBnOpbQwtDeB2Kz1c8QokIUx+AhTM5GSQBYi8MGcmKhe+8MjN//kmHalMZAjpbvf465KC7XWVtG6/PsnLvz3N82eOEAZwkEL3WbXrAdeWogMlasGlhee/ZFtWulQpCNFW2QBWQH/OIYz1JKlhRG/uAlnedNy5d6hAz/42F/9+/P5h7yVutGZ1GTgC3n8zeNLFi7MDZWVVty0GOPIOBFppZWUQgopfCmE8D0lhJJCCF9LpbQkrQA5AbjCFYpyuTwi6ocyqBSpaM6+N2l2/XzcX0TwPFy3hm/ZAK5Xs6gjYjKUlImZuFP4x5EuEg3hRUkwp1UT4UgUth5pT/puAARS8pGBwrM7p37/qx10M8woLYwlMoQ6zUaTizAOfkUglGR2DcaDHC2ALFL69l+eGPuTY9Ur94yizfNm9/oj8wBS1Aej9AYEAFpq5Upm8XlrfAvtE0y0zMiKyeJ6RlY0qXGuV4pIa3r2R7aWluW9cuCCxNtZYssJkAZuISIqTzeJeDNPePxeBEGRvf/nyquHp87/1d3c4EOsRTqNhQBD3Lhp08KlK8oVd3pqUgpJupm+q6TWWpGWutYrRCutSQflOkBaSyV9TYS8kC8WCgUg33XcR6WuEFJLC+fBC08TXFobzz4FtgWVagTFSmUxgYzSwpA/lRZSTkvXiVcPpAFZGaWFkfQnxsgXxQM7Zr50iHwBnXaB7bfSQgQiGvvjo9Ur4+ZwgaSaq/nfKiOrZWlhjRIMkGO7ZCpzG15HiidRWhjt15ZOWj83xJejM+nv/rvr1753qRvqK9X6VmMYxdNk5tj4uRkl9ZJtg6IqkUUwrKRPE18sRNKkFbzvJzbcOTVTHRfcfFhzfDvuF7Jo0aJ9z7+vsGB5fmB4cHRRcXDEyOWBIWklfSGFp4Im6lJJpbQm0qS19qVyfeVIUMjt/MDQ8ILiwEDOYtXpiZmZWu5Q0k7Bzk5j7b+9Jz/IuDGhlJSwLA8fI5ztOT3SH77ApYvZru1QYzSJcPjE+mVQJICcXogGhBgpgwgRhRNGpowp1QMJbo9QH5UUApJ6QNIX5vKFhb2bteNDmz0WsjKymt+HmalEgQDTGjRBUACrNdSgViKtSREoyhx1NpAFAKTIKOXW/tA38KJFUvVg71tlZGGjyUZiypFA9Tz+6ULdUKS0MHRgG21VQq3QehQTQY7+jFy2Z/SJ79/ozUiM1E1lXeo0IIvhyz9/5qs/c0qrGrkoQdoJp9QhIwAhQ+mqoZW59/7YBiX0/DU3nW8QpOOMrDVr148uWuq4fq40yCzLKLim43ieK3xfSymEL4UIMrNQK60UaY0AJjCbG5adsyyLMUNLwUgYIK9fuy6UMpoNkSLrTZ2fy/lQ5NT6QofdcGz1UZpHFeLzfXtxaJBq+jgq4cPBT0DMHBQ2EnYRI92hMRW/S4el04CsKM14mo1WJ/tTqvjirpmvvwWa5nA/MBITjgQ/KdLsz+DctpviOE62SICoHQ903fOgdksLkaGseAOPr1z27Xuu//ZBYyg3DwgShhKoMKRUIiGfPuQvbWZ5YSJfA5qZZphuAcxBLCJooa2SceDHdhgWE45knEUbElM6thb6Pq0oP2we/59Xrx+eIA1H/tvlpz++zp30kWN05HX3kCIJ9KFSK2Ic3Um5+YMLn/juFYf+27V5Ij6Zb9/G6FRYWbbNGTNNA1khl8tpLaUQUkrp+6LG9C6CohAllQ6ydRjnjCEyTVp6nudUmfaKOUN65PkCoTf9ph5QHQnFU+8xmpGF81ydjgBSwfAg27cHfB9ZMqMIWoFacTAogYlQkGYWTbuMPjNUTpEBZFEyKB2xpuveGyPXtzesyO9YWz1ylhVsaB/8iYw8Jc0nlNRb/4HB/dtT1XeuhvpxQSxfGYgGn1xrFGxSupkyAW2VFiJDNeMu/+gT5ePXZk7e5AWb5tLlNwZkRbP+KDPVuL/RkVpVCs5yubA34hAZ+tNy/7/YtnDroDfpM15DOLH1EoaRQ01mno9fqLz+G+cNmyOHw5+5tGr/aB3OiuRDJ31tSKRyMQZ+RT33Q2tuvFkee2fGKs5bsKp/YiFjN645TsUuDFjIEFFKn4hAayJSukaLpZSSREG/KSmlFNLzHM9xhFP1nRkkZRnAkfla91aW32fNkZJPggmOrK44scNIN812LcCr8v17ccliajKaYDIrKVJnh6kaBSNJPiG/o/m0FFIjag1kYRy9SMZCak05ah9grPjibufoua6BrEhJWkjRRWIYmtA2nPNjV3/hc7xog6IUp4yhqnqLP7J35Q9+gGbcOuyHlGkXxzKykLRmtvHYx54/9ZN/TEp1HOCJfwFFfUGKquX0jKw+hNg7zshKXKIuMrIYR3fK3/hNK7f8jdXelEDOGjkIFCvvSHxFJM7B2av/+Vz1np8bNInAr8pXfv7Mt//qE8iRiDB2qiO54U0WmuY5YKglWUX+gZ/c+Dsfe1MLYvwha0zFOtEfxDm/euXK20de82YmpfARdDGfGx4ojQwPDg8PjoyOjC4YHh4eHBgoFnI50zBIKbdSmZ4anx6/W5m8I6qTTLoofSmUJhLCF1J2KmER+iGROoNYu3c1kmFcDlvMWmuwbfbsU6BUKCeGMmDceCNxSpNBDYkbGgxGp9omFXYsTILZb63Da4jkevmd66x1y8htgwE+3dWiWO1nGD2hcCGEwYxSjhdtXqr9MUJ/eMG2Fg3e++KJyVfO8FIOtAbKKguJoDBNj5QxVfVLm5cs/84nVdVHhj0/hDVEDlJN3phX1WdAVjrZO8a7u0dqKLsEspChcNXw2oGn/+lW5SvIMqEy2FGDPdeS7CHz5B9fP//lW/agGVQo2CXj+qHJo5+9nBswSEGrEx615JomJkd/Ri7fOfD8D63xK7LXh6TPvBBE9Hz/1VdeLtjWolVrGDc5twzDQM6QoVZaSSWE73qe77qe63iuI3xP+q6SgpRSUpAmxphhmog4U6mIelvWfvU2Opb8c+TIwnp4EuPGWqoBwKDqsF3b2ZrV4NVzeZMoUpIji0K2OYQixhFieh367pAXEu9YR8kEocgCNORpgiMrZX6IpDUvBWWG1zFntV8g0iZHFkYN3SB4noGYESCiwW/+1kvFzUuNoTwJlXXDU4AsRABCzuS0t/Rbd5XfvDZ5+LJR7FFpYdSNa8WR1bcXpn2OLJorTh34B8/+6Pb8AtufbhQSUlpSXoqYCapAzDybvFw9+F/OhdtGaU32oHHoM5dXPzO6ZPugqCjks7KHRbh/IGhuOCX2fNeKq4fLpz5/Jz9sPETEJx2TvXPOp2cqVy5fLJQGHc9hzEDGAVmQ1quklEpKIbUUSkophZJCKam01pqCjyNjzOBKyfHxCaW1wfl9y+jtXbxkHjmyOmCJJwJEduBpYKwpsePocQZHVvBxgyNjTaascAyWonSKsTZAke5+EKGnxXrtldIkVdDhqhVHVoRxhABRu37hqS3lv3ht9jLDbjmysG3Zw2zDu1W++dlXHvun36R8lUWz2JIji4DgsY89Vzl/Rzk+8q6giq45srBfgaz7xZEVtCN88uObV+5f7E16aGBkcaJp65RoxgX1/D5m8ld/+WzltmcPmc2IBQEyFBX58qfO/o1f24M8TDND0TyOrBMYpJ6hEvobfnzdrZPT07c8w35oiE+M7j52+869LUQGtyozU0IqJaTWmoCUUqQ1BUERqr0CiwyRITDOGAJyxmamy3fujbO5N82eX1Ux64WeX46sVlcFETwf16xiWzeB6zVrQZKtDlI5soiQMz1ZrtWRUJT/KoLpUgJvihHBJrqOI4DWbKDIB4sB/tOKIyu8Y4GrIiUfHSg+u2Py9782S5lhtxxZ7R8PUtoo2eMvnRrY/diC922X007LSoI0sndE7Yr86tFV37v/wi99xSjxHhz59jmy+k8Q3U+OLGToT4uV+xft+rsb/Okal3sjvSWwBzClHDUCHpCi/LB58k9unPvCWER/BL/VZJWM60cmD//W5Wd+cL074aOBzbYiSdCsdhZDzQiIkIHy9OAS+/3/fP0f/uN3HqJ4SMcqJIiI3Lp9Z+zmtTUbt3E773uu7zlKCN8XgJK0VBIZUhDHo/p/EZEhIjKDGybS5bExx3FZIp33YXv1niMr2eUwybVQs/OV4s/sw1yOKpVGcnqSZzSFI6sOGTm/8T/0lRtgm9Bbk4chub69be3IJ76bVLwLa8ILaZJTYXBQkJEnige2T3/pEPmyrSh0hxxZ2OGZZ5Zx4//736Wty82FJfJVsmqlNdk7cian3cUf2Dp17Oq9l84aA3bHiTddc2RhX1+d+eXIQtBC50ftZz65AxiQhsBLaBAvZ/UmiHnGRo5PXXMO/upZI8dTbwppsgeMw5+5vHr/6LKdQ35FBhXvKRxZiWa5EIKz3LLc8N4F+75v5dd//Uph5OEoWe+G3BARhRDvvHPSnZnJ5Qu5QrE4OFIYGh0YWTg4srA4OFoYHM6XSrlCwcrlDds2Tcs0Lc4545xxblnG+MT4tZu3sPPTjdE/XcRLehSNb0SeKWLSEsahpPZycLANwzoKAiAIgUsWsj07wfUQsyCOWCpu7cIQEdqWOn1RXbwKpgFSNym7O/2j6/8N/1EaTcM/eUlcuM5yZv0qZXFkNdsK1QImCORLc0UbZYaZHFkUxw4axFLQDYcjMw0xPnP9My9jBh9orLQQQpVxjQQtLdRjf+8Ze8mA9hR0kUYS48gCSqn7TKxLHwqh1Iys5O8p5EG2f8Fjkkp6at8/3jqybkA6Cnl0R+qHAWNljIlBcou99itnp8dcbjHKipoxlL5++efPSU81vZDYAWyCctGCz0ZskoM3LQ/8g9Wr9w17M5JxfDRVCBEZhnH7zt1TJ99CrQzOGePcMLlpcdM27LxpFyw7b1g5wzRNwzIMk3NmcMYZMw2uhHfx8jXX81iHuQepVGvYhoYIqxzqjWcf1hQt05PaI+JM8upQ9m2hOorFnnwChodIycQQMDKC9PwxFAePAulGifqc3LCkbueMfOG8dgI4hzqemb3+aZRCSpde3IWtPaQs5oBEdg020/S7mS1pbRRzk6+dvfuFt4wBO5vtChMpcI1Sa9S+shcPPvZ9z9ZCRD05gHUfrKMswT7x3NMysiAZd0NKMTpmF20cvbK/+SOrN3zzKq/sM46xbLpoz1pIdU+1otygeeZ/3Tz7v8bsQbOF7xhkZ904MnnoM1dyA4ZWsbXHjL1DiFAzolbATPzgT67PDZpKaOx7JTInivWTJ0/duHzeCKrCQGNQp1NDrBhjjDHOGEOkxr8R6MqVK3fvjTPGumgvRBl/Sb4n+UO6H7eJwu5J++F0nO0N8cErBYMD7Om9IETQ9yb6FUSpLnnNACC0THXzlnz7LNo29LQ6J3T5CHOWe/S0ujuJpgERxyy2IBRbv0CqaFfYG1bkt6/R4UhPCyArS7qGkPW5bS3xnDX2P151Lt1lOaum2CJzaH2+CDnKaW/BCxsXfXCrnPY6Y6yiFuZFOkdW05TvYxg4kUoT48jqUhEiR1GVCzYNPfmPtkqnbmPFWxJizIeLjYMIDJtN33AO/vJZbs3uz2lJ9qBx5LcuXzs0aZc46VZ7mVUKyjj4FbVkS+k9n1jjVxX2vQ5hXV8nxpjjeUePHJ6evMsZglaMNIJmoBkQImHQPBV0EAMBRJOzO7fHLl+7MZcL3R9GVY85sijbf0rbNAaux3Ztx2VLgga3CBhDO1pwZAERmqY8/BaVp4HzeVshQsPQdya8o6fRDgTuLBxZcXuUADkrvXc3tshX6JYji7qcEZdl99qnX6qLZoraxTEgi+LsYwTAULti9fc+nV89otxOigDmzpHVb0DW/HFkIZAiZrJnfnSHHbHlKfqwcFJvFMgKNJsmw2YHf/Vc+brDbd5OvLAOZ50VrkaOkM2Rlaoeg3x5xtGZErs+unTnty1xpgQz+lqLsDmICDI4v313/M1jR8mbZshJa9CKSJFW9eXWDAA0IKLF2czU+IVLl+Xcvfg2hPJ98MVT3PA5cGTRLBIybO1osCz2zD7QOh0CivwrxpFFwLmeqchDb3XAqd7VAhERGNx57S3y/LAbgSlyPJo+Vb+N2vXzO9dZa5eSl1FmmMmRFW+aEquO7+7kkNa8ZJePXLr958d4KZX2KgXIimwFgpbKHCqs+diBORdthImQMZYlSJAOEvURkBXilMLYEkaNsE45soIsrD0f27R07wJ/JtROijCxIxgrw23UzpIie9A898Vbp//iRmsIKwXOOjp16DOXcwPhxNxGn4SYjQfJBszBdgpPv/eTaxeuL4qq6ud6wzkBWUTEObtw8fL5M6cYaAAirUgrIF2rQSMCIiLFOHedmfOXLlccl/VuOWhej3gXQ6AYkBWxArG9Z2VhcU0XxPNw83q2fk2DlzcBZGWtDEIQSD91Tl0fg/lUIUEeHtqWf/66f+4qy1nBdcrgyKrdMKKox6A0K9ilFx4nOVv8maKoByVRJOhJC0nSmhessd89WDl7ixesRlCkBZAVqxBCxmTFG3lqzbJv2Smm3ShDV9tAVpQYllojq337onoeRes5d8KRhRz9snjsxaXbv3u9PyUwrX1nSJpTvcw1fpG5xSp3vNd++UynTkAAZx3+rStXD01aRaOeVRULp0fnSPF/IkPl6+JC8wP/cj30dy+MubabRUSt9fETJ29eu2gaBiCjhj9GOtgZxg0tnEuXr9y9N8HwIcgxaLPxGiV9UkxkZHWIRbd5UtizT0NApoMRFCfpGFHyqBLJg8dmI+rolTZG8oXz6lvAWHKCFPZYamB1tNMVQ3L94r4t5tIREjJFi2RwZCXRKmyk3sBc+3YgZ9oR1z/9NRKq4V21yMiiuvJuqjNEVfVXftdTpU2LldMe8UnbHFmxdUHq3/vVbkYWtXtNkKHydHFJ/ul/tiPwGxBTbm0aK2jku0iDkeOv/5ezU5erRq7jKr9AAbz0qXPCVczAkI2UoBiKNKJuliVTjdRLrntu+JmPrXSn+jc7a64qpBYUcd2jx45P3r1lGRyBM0QgRRSEQwBA37px/frY7ay+IP35wi6ArB5xZGUmLgfdCVetZNu2kOdBZsN5Sp8FAViWvj4mT55D25qvQHoUc2M5yz12Vt4eR9OIrUWSIyvCahyk6wtpjA4Wn9lGrp+iQubCkdW9I0K8YE+/dW3sDw4ZxVwgX4hmA7IwOl2led5a+wPPocFJdzeodzmy0jZH6n2f2D6wsiDdQMFnpUJBOkcWglZkDxoX/+rWqT+9niwkbB/Ounls6tCnL9slI+i5l86RlQSyQjqFGeiW5TPfv3LdgRF3uk+1CJv7IwI4a3xi6siRQ870hMkZBXxjWgeksBO3xy5duZGqyfvZy+6OySgKMnQPu2cZ9SAl2/8UFAqgVBK4oRRIpUlfQkRoGuLQcZqpzGMgPfYyDDU+5R4+hbYZKK0EFpySkRXK3mfaF6XndvKhIijVghc8E7uLpxP04OCR1rxo3/rjw+XjV3jBAqURYbaUuuggGaqqN7RzxYqP7pEzHjLW/nFMwJWxYpeHhyMrZXzhLAQKeyuzyzKO3pTY9rfWrn3/ci81Ck2J5ybC3aSJm6x6z3/tP5+dSwSiBmd99urVQ5NWKebHtDgrsZ40SBoYww/+y3WFUVP6Ol3ZPuwqBGpkS+zWnXtHjhx1ZyaZYSIFnFhUmZo4d/GS6/ldZ6fd/2XC9o5/GxlZHXNkpVa6NJ8tJCxcwJ7YBZ5XK7ijBJCV4MhqEkZxTuUZdfjEvAbSk4cDDe4efJscHziDlHB6SkZW85IxIF9aqxYW9m5KKTOcjSMrg2CpF4eKISl97dMvqaqPRoPnrUVGVrgfOCAAMCZnvBUf3T30+ApZ8WYRWG1zZEXLXbEPPf04R1YsB73uKEaQQJrFvEOGfkUufnx0zw9sFjMymg0VdzsiDZkp8isiMAv80G+cG78wE6ZT7EaMMNSCXvqP50RVMx6uYSBIkLaFbmtEySEDr6oWbii+75NrpKsxCnn0g3nAeiVqCYAzdv3G2NFjR5zyBHKLMZyZvHfm7NmZihO7Hh3pT3pQR7yd6RNFkMxk+8vI6ZijB4LgeezJPTA6AlLG8nZDmi3070btKwFoDTlLvnNG3bwFlnVfVYht+Rdv+Gcu19GzesyQEheBKO5KBf+ReuDFx9E2MhMrqUWFRopv1oPJa+J5q3ru9s3/eZDlrebA0lMaKFSGHKKM18QMtvb7D9Qi8zib0ULp86GYNd8sg+pvL4QSI0/1QhJSM9k2QEtt5Pn+T+40bK6lbj4scxcAGkUp9UGQInvAvPTS7Xf+6Gpu0Jgjvwhpskr85puTbzThrKbqp7D9SWFMp74y1PSunEmx8yNLdn10SXVS9BucxXooagmAcXZz7M7Ro0euXjp7/fLZs+fOj09Os4QDQv3O2d6G+sAgRRABG/B6/e8NGwqxiXmytqbcoi81KQWlInv6KZASWP3hGM3prA8Jm7QajbchaJIHjz6I1UKSynn1BHIG0Bx5HWBrFugiYrTqHwERGJIncptW5rclygxDUaPaR7G57PVUA4z8oLZePTDPSWleyt3+izenXr9gDORIU/Bd9fE0N6gx5eYGBb/iqBwxsHnx6u9+UlZbeuoIoe1uPKSxyfUZNp7Pah9B7LuQI4YPZmMi9UXD+kJhZNEi4UFKWFeiKvf+w62LdoyIqmQGa5yd6GdDhwEb61b7EiDgNnMn/dd+6TSGb+5czAxJ9qB5+LNXr7w+YQ+apBtHHptjqPf5aZyL0Mhr68E4Cld9w4+sWbq16FUUskdFhaQ/kbG7E1Mn3n7n5JmL41MzjOHDrzCimB0RkAZNqAm0BtJIdY4prZF0QBuFpEFr0I1fUTv94zKZ3oNc3se347Il4LpAgKGHE2kgDURUY6zSVB8SBYNUGk1DX7yiTl/AnH0/AulRe4zlLPfNs+LabTQ5qWBlCHV9Mesjr42fCII2HlSbI2kNiAPv2YUxykWCBjEXNf9S/1Rtp3S9KUjth6SJ6tvUC/2IVz/9snerjJyB0qFhhIcU+QtpIl1/J4Iou0u/efuC/WulIzLhLAJS9YcQBQtIuj6d5N9V+Lv6KymUiEiR1hAaLQQDjoxf1X8VmlFKajhDURHrPrhy87evcSe9oKSDNJAmHX64ij8cot+oFTHODv3mufGzM0a+Z1zryFBL/dLPn3MmfGSoVWMAEExN69pS6Nogw8tCWulgZ6Wr7QHjA/9inVVoUff+IAyC4WXr5imW8OiojfDpH10AhtFa9KTkeQTssUrB+Hinn23+U2sYGcZ8Lr2isFVRQk0JUaVKU2VgD8iG0ZqPDtbGj7OsQEZfJxK3J5sLSISmYSwcigQGMI1xLONuq6onx2fmam8iklDmwqJRyoHS2U9r1fUEOSpHeHdmUkF80mQULXtBgXSYuD8j7y7t4f6k60+5fVKhVlhS4FYtetRZQzYEragyVo3IdwRSVFpeMGxOimbPpIyvDja6/5Cm8rXqPDjhoAQNLretgqE14Wxjyvo9aeIWm7ru+v1UbDgvKuRRfkk5q+maqUERwTDm9O1KdetAIAABY7Pqv3nFL0go0N0GhQLhaRpxg1aouLJt34RhiAbviZAgoaim2qm1KEgfHRFyhmYm3EmaSHZvfCLHdmsY74MtIXSXecwEgMgtllxa5WvShM3+Q9hNJSlCysN7pEWkT3P3bIjAsFhfAVkPjQrBPnFr5mixdoJlUc+/HR50tfJ8jH/+d6S3U8PWCZ0tETNq49hkPrpvYAFE7PI+B3XklM71XONSm+NxmLdegb0KSvUVigVddy3sFXjV/qeoI1Hb9le3BzSExjk/PRbDY6C+VQA9OP70cDyzd8PAtKyTbr+BOrogfXwKutVnLQtviKifF4Lo0QT3e6ZC6D5+qicfb99e6bkD1EJ7Yfbs8CEUFn+tXtHmE03Gs4dxIjTbaXz39e4reLE2j1RWptAcnTPs6gkYpsHonRyHbp+Jc3szRSfVmtec5rDO777uk705h7PdV+Of+1V99/XIv2b3QjBqm1Ca2dW1pUPtfTWlORDdQaltOMRdOjTUyZtbKJXWq4rdjvDd1/2RvI/GmmN79/fd1wPxDh8yFUJz+G3XymM+BD2k0cS2sytzHGoPZf27l/YhVScPo+agd32OPhP9/Xmo2H1YF2zbA3hkrjq2fUvpvouGd1/vvtq8F3TfL84jeYAfbcuP9cNxfJQc/NaHZu6RJJznQ4zvot7v6o/+uGj48KeQ4MPwpXMcJHuoz9lDd7uo7693kpvr3dej98L2foh9cOXf9T86XS66v4Nk/XkI8FG8tNhelPKREU/vOjSPgGijRxFLeHdne/hiqZIuVfZ1nUdLLaVqqgBqv9/4vIonnPOnsPO8td7KXJxzznEXOhLTSgoeIl3SIoW962XBPptg1n5RV1N+gCe2P126vz6DZB3psbmkFqTWQ1BLZ7mdac+r1u1J3lcXfiXNwwXD+ZwyzM+Y+82m6y6dmub/Gs9lXpjxQ2zbn57vZNOYRu83Zdznntmstw/nti8s9WxlWWHUu9vY+ufYrfx9BF7Y07LH+ym8qG9G0quJYE+fSf20ApRtssxKFUnzKdApY0h/rVI652M9sddToCwvZNbL08IxxwwjJfXhmPb+MEvEfUax2vzGLlamUyowyv5e6hATe4jOeh86/j0R+tjyFvSPIkk6JZRGf5yMjvRcNWKGN/9uqUrXAm3+1s1oUy9R58II2w7BUYb505Oiv946p92V/nV0x3qYjE/3vXfLI3PJqXfHjGaT2g9QR2ZtX4wmi9q4LzQ/i/9w+a/tS5L7dhnne93+f599DgheNyN9AAAAAElFTkSuQmCC";

// ── Dane startowe ─────────────────────────────────────────────────────────────
const INITIAL_USERS = [
  { id: 1, name: "Admin", email: "admin@sklep.pl", password: "admin123", role: "admin", discount: 0 },
  { id: 2, name: "Jan Kowalski", email: "jan@example.com", password: "haslo123", role: "customer", discount: 10 },
  { id: 3, name: "Anna Nowak", email: "anna@example.com", password: "haslo123", role: "customer", discount: 5 },
];

const DEFAULT_UNITS = [
  { value: "szt", label: "sztuka" },
  { value: "kg", label: "kg" },
  { value: "tys", label: "tysiąc" },
  { value: "opak", label: "opakowanie" },
];

// Mapa typowych skrótów jednostek z systemów WF-Mag/innych na nasze symbole.
// Używana do automatycznego dopasowania jednostki z CSV do istniejącej lub
// do podpowiedzi sensownej etykiety, gdy trzeba założyć nową jednostkę.
const UNIT_ALIASES = {
  "szt": "szt", "sztuka": "szt", "sztuk": "szt", "pcs": "szt", "pc": "szt", "ks": "szt",
  "kg": "kg", "kilogram": "kg", "kilogramy": "kg",
  "g": "g", "gram": "g", "gramy": "g",
  "t": "t", "tona": "t", "tony": "t",
  "tys": "tys", "tysiąc": "tys", "tys.": "tys",
  "opak": "opak", "opakowanie": "opak", "op": "opak", "op.": "opak",
  "kpl": "kpl", "komplet": "kpl", "komplety": "kpl",
  "par": "para", "para": "para", "pary": "para",
  "m": "m", "mb": "m", "metr": "m", "metry": "m",
  "m2": "m2", "m²": "m2", "metr2": "m2",
  "m3": "m3", "m³": "m3", "metr3": "m3",
  "l": "l", "litr": "l", "litry": "l",
  "pal": "pal", "paleta": "pal", "palety": "pal",
};

const INITIAL_PRODUCTS = [
  { id: 1, name: "Laptop Pro 15\"", category: "Elektronika", subcategory: "Laptopy", price: 4999, stock: 10, weight: 2.2, unit: "szt", image: "💻", description: "Wydajny laptop do pracy i rozrywki", sku: "LAP-001" },
  { id: 2, name: "Słuchawki Bluetooth", category: "Elektronika", subcategory: "Audio", price: 299, stock: 25, weight: 0.3, unit: "szt", image: "🎧", description: "Bezprzewodowe słuchawki z ANC", sku: "SLU-002" },
  { id: 3, name: "Kawa Arabica 500g", category: "Spożywcze", subcategory: "", price: 45, stock: 100, weight: 0.5, unit: "opak", image: "☕", description: "Świeżo palona kawa arabica", sku: "KAW-003" },
  { id: 4, name: "Plecak Turystyczny", category: "Sport", subcategory: "Plecaki", price: 189, stock: 15, weight: 1.1, unit: "szt", image: "🎒", description: "30L plecak wodoodporny", sku: "PLE-004" },
  { id: 5, name: "Książka: React od Zera", category: "Książki", subcategory: "", price: 59, stock: 50, weight: 0.6, unit: "szt", image: "📘", description: "Kompletny przewodnik po React", sku: "KSI-005" },
  { id: 6, name: "Smartwatch Fit", category: "Elektronika", subcategory: "Smartwatche", price: 799, stock: 8, weight: 0.2, unit: "szt", image: "⌚", description: "Smartwatch z monitorem zdrowia", sku: "SMA-006" },
];

// ── Logika przesyłek ──────────────────────────────────────────────────────────
const PACKAGE_MAX_KG = 25;
const SHIPPING_PER_PACKAGE = 15;
const FREE_SHIPPING_THRESHOLD = 400;
const HALF_PALLET_THRESHOLD_KG = 100;
const FULL_PALLET_THRESHOLD_KG = 200;
const SHIPPING_HALF_PALLET = 120;
const SHIPPING_FULL_PALLET = 200;

// Oblicza ile paczek potrzeba metodą "bin packing" (first-fit) na podstawie wagi i ilości każdej pozycji w koszyku
function calculatePackages(cartItems) {
  // Rozbij każdą pozycję na pojedyncze jednostki wagowe (qty x weight), żeby poprawnie pakować pojedyncze produkty do paczek
  const units = [];
  cartItems.forEach(item => {
    const w = item.weight || 0;
    for (let i = 0; i < item.qty; i++) units.push(w);
  });
  // Sortuj od najciężutszych — lepsze upakowanie (first-fit decreasing)
  units.sort((a, b) => b - a);

  const packages = []; // każda paczka to suma wag
  units.forEach(w => {
    // Jeśli pojedyncza jednostka sama przekracza limit paczki, dzielimy ją na własne, osobne paczki
    if (w > PACKAGE_MAX_KG) {
      let remaining = w;
      while (remaining > 0) {
        const chunk = Math.min(remaining, PACKAGE_MAX_KG);
        packages.push(chunk);
        remaining -= chunk;
      }
      return;
    }
    // Spróbuj zmieścić w istniejącej paczce
    let placed = false;
    for (let i = 0; i < packages.length; i++) {
      if (packages[i] + w <= PACKAGE_MAX_KG) {
        packages[i] += w;
        placed = true;
        break;
      }
    }
    if (!placed) packages.push(w);
  });
  return packages; // np. [24.5, 18.2] -> 2 paczki
}

// Klasyfikuje sposób wysyłki na podstawie całkowitej wagi koszyka:
// > 200kg -> europaleta, > 100kg -> 1/2 palety, inaczej liczone paczki po max 25kg
function classifyShipment(cartItems) {
  const totalWeight = cartItems.reduce((s, i) => s + (i.weight || 0) * i.qty, 0);
  if (totalWeight > FULL_PALLET_THRESHOLD_KG) {
    return { type: "pallet", label: "Europaleta", count: 1, totalWeight, baseCost: SHIPPING_FULL_PALLET };
  }
  if (totalWeight > HALF_PALLET_THRESHOLD_KG) {
    return { type: "half-pallet", label: "1/2 palety", count: 1, totalWeight, baseCost: SHIPPING_HALF_PALLET };
  }
  const packages = calculatePackages(cartItems);
  return { type: "packages", label: packages.length === 1 ? "1 paczka" : `${packages.length} paczki`, count: packages.length, totalWeight, baseCost: packages.length * SHIPPING_PER_PACKAGE, packages };
}

// Wzorcowy CSV z WF-Mag (do pobrania jako przykład)
const SAMPLE_CSV = `Indeks;Nazwa;Kategoria;Cena netto;Cena brutto;Stan magazynowy;Opis;Jednostka
LAP-001;Laptop Pro 15";Elektronika;4064,23;4999,00;12;Wydajny laptop do pracy i rozrywki;szt
SLU-002;Słuchawki Bluetooth;Elektronika;243,09;299,00;30;Bezprzewodowe słuchawki z ANC;szt
KAW-003;Kawa Arabica 500g;Spożywcze;36,59;45,00;85;Świeżo palona kawa arabica;kg
PLE-004;Plecak Turystyczny;Sport;153,66;189,00;20;30L plecak wodoodporny;szt
KSI-005;Książka: React od Zera;Książki;47,97;59,00;60;Kompletny przewodnik po React;szt
SMA-006;Smartwatch Fit;Elektronika;649,59;799,00;3;Smartwatch z monitorem zdrowia;szt
MON-007;Monitor 27" 4K;Elektronika;1219,51;1500,00;5;Profesjonalny monitor do pracy;szt
MYS-008;Mysz bezprzewodowa;Elektronika;81,30;100,00;40;Ergonomiczna mysz optyczna;szt
KLA-009;Klawiatura mechaniczna;Elektronika;243,09;299,00;18;RGB, przełączniki Blue;szt`;

// Domyślne mapowanie kolumn WF-Mag → sklep
const DEFAULT_MAPPING = {
  sku: "Indeks",
  name: "Nazwa",
  category: "Kategoria",
  price: "Cena brutto",
  stock: "Stan magazynowy",
  description: "Opis",
  unit: "Jednostka",
};

const EMOJI_MAP = {
  "Elektronika": "💻", "Spożywcze": "🛒", "Sport": "🏋️",
  "Książki": "📘", "Odzież": "👕", "Dom": "🏠",
  "Zdrowie": "💊", "Motoryzacja": "🚗", "Zabawki": "🎮",
};
const getEmoji = (cat) => EMOJI_MAP[cat] || "📦";

const fmt = (n) => (+n || 0).toLocaleString("pl-PL", { style: "currency", currency: "PLN" });
const parseNum = (s) => parseFloat(String(s).replace(",", ".").replace(/\s/g, "")) || 0;

// ── Style ─────────────────────────────────────────────────────────────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Inter',sans-serif;background:#f5f5f5;color:#1c1c1c}
  :root{
    --primary:#1cb88a;--primary-dark:#17956f;--primary-light:#e3f7ef;--primary-mid:#3fc98a;
    --success:#2d8a4e;--danger:#c0392b;--warning:#e67e22;
    --surface:#fff;--border:#e0e0e0;--muted:#7a7a7a;
    --radius:10px;--shadow:0 1px 4px rgba(0,0,0,.08),0 1px 2px rgba(0,0,0,.05);
    --shadow-md:0 4px 12px rgba(28,184,138,.15),0 2px 4px rgba(0,0,0,.06);
  }
  .app{min-height:100vh;display:flex;flex-direction:column}
  .navbar{background:#111722;color:#fff;padding:0 20px;min-height:62px;display:flex;flex-direction:column;justify-content:center;position:sticky;top:0;z-index:100;box-shadow:0 2px 8px rgba(0,0,0,.35);border-bottom:3px solid var(--primary)}
  .navbar-inner{display:flex;align-items:center;justify-content:space-between;width:100%;gap:12px;flex-wrap:wrap;padding:8px 0}
  .navbar-brand{font-size:1.2rem;font-weight:700;letter-spacing:-.5px;color:#fff;white-space:nowrap;flex-shrink:0}
  .navbar-brand span{color:var(--primary)}
  .nav-left{display:flex;align-items:center;gap:4px;flex-wrap:wrap}
  .nav-right{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-left:auto}
  .main{flex:1;padding:28px 24px;max-width:1300px;margin:0 auto;width:100%}

  .btn{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border:none;border-radius:8px;font-size:.875rem;font-weight:500;cursor:pointer;transition:all .15s;white-space:nowrap}
  .btn-primary{background:var(--primary);color:#fff}.btn-primary:hover{background:var(--primary-dark)}
  .btn-secondary{background:var(--surface);color:var(--primary);border:1.5px solid var(--primary)}.btn-secondary:hover{background:var(--primary-light)}
  .btn-danger{background:var(--danger);color:#fff}.btn-danger:hover{background:#a93226}
  .btn-success{background:var(--success);color:#fff}.btn-success:hover{background:#236b3d}
  .btn-warning{background:var(--warning);color:#fff}.btn-warning:hover{background:#ca6f1e}
  .btn-ghost{background:transparent;color:#fff;padding:6px 12px}.btn-ghost:hover{background:rgba(255,255,255,.12);border-radius:8px}
  .btn-ghost.active{background:var(--primary);border-radius:8px}
  .btn-sm{padding:5px 10px;font-size:.8rem}
  .btn:disabled{opacity:.5;cursor:not-allowed}

  .card{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:20px;border:1px solid var(--border)}
  .card-title{font-size:1.1rem;font-weight:600;margin-bottom:16px;color:#1c1c1c}

  .form-group{margin-bottom:14px}
  .form-label{display:block;font-size:.875rem;font-weight:500;margin-bottom:5px;color:#333}
  .form-input{width:100%;padding:9px 12px;border:1.5px solid var(--border);border-radius:8px;font-size:.875rem;outline:none;transition:border .15s;background:#fff;color:#1c1c1c}
  .form-input:focus{border-color:var(--primary);box-shadow:0 0 0 3px var(--primary-light)}
  .form-select{width:100%;padding:9px 12px;border:1.5px solid var(--border);border-radius:8px;font-size:.875rem;background:#fff;outline:none}
  .form-select:focus{border-color:var(--primary)}

  .badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:.75rem;font-weight:500}
  .badge-blue{background:#e3f7ef;color:#17956f}
  .badge-green{background:#e6f4ec;color:#2d8a4e}
  .badge-orange{background:#e3f7ef;color:#1cb88a}
  .badge-red{background:#fdecea;color:#c0392b}
  .badge-gray{background:#f0f0f0;color:#555}
  .badge-yellow{background:#fef6e4;color:#b7770d}

  .tabs{display:flex;gap:8px;background:transparent;border-radius:10px;padding:0 0 4px;margin-bottom:24px;flex-wrap:nowrap;overflow-x:auto;scrollbar-width:thin}
  .tabs::-webkit-scrollbar{height:5px}
  .tabs::-webkit-scrollbar-thumb{background:#d1d5db;border-radius:99px}
  .tab{flex-shrink:0;padding:9px 18px;border:2px solid var(--primary);border-radius:999px;background:#fff;font-size:.85rem;font-weight:600;cursor:pointer;transition:all .15s;color:var(--primary)}
  .tab:hover{background:var(--primary-light)}
  .tab.active{background:var(--primary);color:#fff;box-shadow:0 2px 8px rgba(28,184,138,.35);border-color:var(--primary)}

  .subcat-tabs{margin-top:-12px;margin-bottom:20px;gap:6px}
  .tab-sub{padding:6px 14px;font-size:.8rem;border-color:#7dd3fc;color:#0369a1}
  .tab-sub:hover{background:#e0f2fe}
  .tab-sub.active{background:#0369a1;color:#fff;border-color:#0369a1;box-shadow:0 2px 8px rgba(3,105,161,.3)}

  .login-tabs{display:flex;gap:4px;background:#ececec;border-radius:10px;padding:4px}
  .login-tab{flex:1;padding:8px 14px;border:none;border-radius:8px;background:transparent;font-size:.875rem;font-weight:500;cursor:pointer;transition:all .15s;color:var(--muted)}
  .login-tab.active{background:#fff;color:var(--primary);box-shadow:var(--shadow)}

  .products-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:20px;margin-top:20px}
  .product-card{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);border:1px solid var(--border);overflow:hidden;transition:box-shadow .2s,transform .2s;display:flex;flex-direction:column}
  .product-card:hover{box-shadow:var(--shadow-md);transform:translateY(-2px);border-color:var(--primary-mid)}
  .product-emoji{font-size:3rem;text-align:center;padding:20px 0 14px;background:#f2fbf7;border-bottom:1px solid #cdeee0;overflow:hidden}
  .product-photo{width:100%;height:120px;object-fit:cover;display:block}
  .product-photo-thumb{width:32px;height:32px;object-fit:cover;border-radius:6px;margin-right:7px;vertical-align:middle}
  .cart-item-photo{width:38px;height:38px;object-fit:cover;border-radius:6px}
  .photo-upload-row{display:flex;gap:14px;align-items:flex-start}
  .photo-preview{width:64px;height:64px;border-radius:10px;background:#f8fafc;border:1.5px solid var(--border);display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0}
  .photo-preview img{width:100%;height:100%;object-fit:cover}
  .product-body{padding:12px;flex:1;display:flex;flex-direction:column;gap:7px}
  .product-name{font-weight:600;font-size:.9rem;color:#1c1c1c}
  .product-desc{font-size:.78rem;color:var(--muted);line-height:1.4;flex:1}
  .product-price{font-size:1.15rem;font-weight:700;color:var(--primary)}
  .product-price-original{text-decoration:line-through;color:var(--muted);font-size:.82rem;font-weight:400}
  .product-price-discount{color:var(--success);font-size:.78rem;font-weight:600}
  .product-footer{padding:10px 12px;border-top:1px solid var(--border);background:#fafafa}
  .product-sku{font-size:.72rem;color:var(--muted);font-family:monospace}

  .table-wrap{overflow-x:auto}
  table{width:100%;border-collapse:collapse;font-size:.875rem}
  th{background:#e9f8f1;padding:10px 14px;text-align:left;font-weight:600;border-bottom:2px solid #bfe8d4;white-space:nowrap;color:#333}
  td{padding:9px 14px;border-bottom:1px solid var(--border);vertical-align:middle}
  tr:last-child td{border-bottom:none}
  tr:hover td{background:#fff8f5}

  .stats-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:14px;margin-bottom:22px}
  .stat-card{background:var(--surface);border-radius:var(--radius);padding:16px;box-shadow:var(--shadow);border:1px solid var(--border);border-left:4px solid var(--primary)}
  .stat-value{font-size:1.7rem;font-weight:700;color:var(--primary)}
  .stat-label{font-size:.78rem;color:var(--muted);margin-top:3px}

  .cart-drawer{position:fixed;top:0;right:0;width:370px;height:100vh;background:var(--surface);box-shadow:-4px 0 20px rgba(0,0,0,.15);z-index:200;display:flex;flex-direction:column;transform:translateX(100%);transition:transform .25s ease}
  .cart-drawer.open{transform:translateX(0)}
  .cart-header{padding:18px;border-bottom:2px solid var(--primary);display:flex;justify-content:space-between;align-items:center;background:#e9f8f1}
  .cart-items{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:10px}
  .cart-item{display:flex;gap:9px;align-items:center;padding:9px;background:#f2fbf7;border-radius:8px;border:1px solid #cdeee0}
  .cart-item-emoji{font-size:1.8rem}
  .cart-item-info{flex:1;min-width:0}
  .cart-item-name{font-weight:500;font-size:.85rem}
  .cart-item-price{color:var(--primary);font-weight:600;font-size:.82rem}
  .cart-qty{display:flex;align-items:center;gap:5px;margin-top:4px}
  .qty-btn{width:22px;height:22px;border-radius:50%;border:1.5px solid var(--border);background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.85rem}
  .qty-btn:hover{border-color:var(--primary);color:var(--primary)}
  .qty-val{width:28px;text-align:center;font-size:.85rem;font-weight:600}
  .cart-footer{padding:14px;border-top:1px solid var(--border)}
  .cart-total-row{display:flex;justify-content:space-between;padding:6px 0;font-size:.875rem}
  .cart-total-final{font-weight:700;font-size:1.05rem;color:var(--primary);border-top:2px solid var(--border);margin-top:4px;padding-top:9px}
  .overlay{position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:150}

  .alert{padding:11px 15px;border-radius:8px;margin-bottom:14px;font-size:.875rem;display:flex;align-items:center;gap:7px}
  .alert-success{background:#e6f4ec;color:#2d8a4e;border:1px solid #b7dfc5}
  .alert-danger{background:#fdecea;color:#c0392b;border:1px solid #f5c6c2}
  .alert-warning{background:#e3f7ef;color:#17956f;border:1px solid #bfe8d4}
  .alert-info{background:#e3f7ef;color:#1cb88a;border:1px solid #bfe8d4}

  .modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:300;display:flex;align-items:center;justify-content:center;padding:16px}
  .modal{background:#fff;border-radius:var(--radius);width:100%;max-width:560px;box-shadow:0 20px 60px rgba(0,0,0,.2);max-height:90vh;overflow-y:auto;border-top:4px solid var(--primary)}
  .modal-header{padding:18px 22px 0;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:#fff;z-index:1;padding-bottom:12px;border-bottom:1px solid var(--border)}
  .modal-body{padding:18px 22px 22px}
  .modal-title{font-size:1.05rem;font-weight:600}
  .close-btn{background:none;border:none;font-size:1.3rem;cursor:pointer;color:var(--muted);line-height:1}

  .login-page{min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(145deg,#111722 0%,#1a2030 50%,#111722 100%)}
  .login-card{background:#fff;border-radius:16px;padding:38px;width:100%;max-width:400px;box-shadow:0 25px 60px rgba(0,0,0,.4);border-top:5px solid var(--primary)}
  .login-logo{text-align:center;font-size:2.4rem;margin-bottom:6px}
  .login-title{text-align:center;font-size:1.35rem;font-weight:700;margin-bottom:5px;color:#1c1c1c}
  .login-sub{text-align:center;color:var(--muted);font-size:.85rem;margin-bottom:26px}

  .page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;flex-wrap:wrap;gap:10px}
  .page-title{font-size:1.35rem;font-weight:700;color:#1c1c1c}
  .search-bar{display:flex;gap:10px;margin-bottom:18px;flex-wrap:wrap;align-items:center}
  .search-bar .form-input{max-width:260px}
  @media (max-width: 640px) {
    .search-bar{flex-direction:column;align-items:stretch}
    .search-bar .form-input{max-width:none}
    .search-bar .tabs{width:100%}
  }

  .cart-badge{background:var(--primary);color:#fff;border-radius:999px;font-size:.68rem;font-weight:700;min-width:17px;height:17px;display:inline-flex;align-items:center;justify-content:center;margin-left:2px;padding:0 4px}
  .tag{display:inline-block;padding:2px 7px;border-radius:4px;font-size:.73rem;font-weight:500;background:#e3f7ef;color:#17956f}
  .tag-sub{background:#e0f2fe;color:#0369a1}

  .category-block{border:1px solid var(--border);border-radius:8px;overflow:hidden}
  .category-block-header{display:flex;align-items:center;gap:10px;padding:10px 12px;background:#fafafa;cursor:pointer;transition:background .15s}
  .category-block-header:hover{background:#f0f0f0}
  .category-block-body{padding:12px;border-top:1px solid var(--border);background:#fff}
  .cat-remove-btn{background:none;border:none;cursor:pointer;color:var(--danger);font-weight:700;font-size:.85rem;padding:2px 6px;margin-left:auto;border-radius:4px}
  .cat-remove-btn:hover{background:#fdecea}
  .discount-box{background:linear-gradient(135deg,#e3f7ef,#bfe8d4);border-radius:6px;padding:9px 13px;font-size:.85rem;margin-bottom:9px;border:1px solid #9fdcc0}
  .shipping-info-box{background:#f8fafc;border:1px solid var(--border);border-radius:8px;padding:10px 13px;font-size:.85rem;margin-bottom:9px}
  .shipping-progress{height:6px;background:#e5e7eb;border-radius:999px;overflow:hidden;margin-top:6px}
  .shipping-progress-bar{height:100%;background:var(--primary);border-radius:999px;transition:width .3s}

  .csv-dropzone{border:2.5px dashed #7fd1ac;border-radius:12px;padding:40px 20px;text-align:center;background:#f2fbf7;cursor:pointer;transition:all .2s;margin-bottom:20px}
  .csv-dropzone:hover,.csv-dropzone.drag-over{border-color:var(--primary);background:#e3f7ef}
  .csv-dropzone-icon{font-size:2.8rem;margin-bottom:10px}
  .csv-dropzone-text{font-size:1rem;font-weight:600;color:var(--primary);margin-bottom:4px}
  .csv-dropzone-sub{font-size:.82rem;color:var(--muted)}
  .mapping-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:18px}
  .mapping-row{display:flex;align-items:center;gap:8px;padding:8px 12px;background:#f2fbf7;border-radius:8px;border:1px solid #cdeee0}
  .mapping-label{font-size:.82rem;font-weight:600;color:#333;min-width:110px}
  .mapping-arrow{color:var(--primary);font-size:.8rem}
  .preview-table-wrap{overflow-x:auto;max-height:280px;border-radius:8px;border:1px solid var(--border)}
  .preview-table{width:100%;border-collapse:collapse;font-size:.8rem}
  .preview-table th{background:#111722;color:#fff;padding:8px 10px;white-space:nowrap;position:sticky;top:0}
  .preview-table td{padding:7px 10px;border-bottom:1px solid #f5f5f5}
  .preview-table tr:hover td{background:#f2fbf7}
  .row-new{background:#e6f4ec !important}
  .row-update{background:#e3f7ef !important}
  .row-unchanged{background:#fff !important}
  .import-legend{display:flex;gap:14px;font-size:.78rem;margin-bottom:10px;flex-wrap:wrap}
  .legend-dot{width:10px;height:10px;border-radius:50%;display:inline-block;margin-right:4px}
  .sync-bar{background:#111722;color:#fff;padding:8px 14px;border-radius:8px;font-size:.82rem;display:flex;align-items:center;gap:10px;margin-bottom:18px;border-left:4px solid var(--primary)}
  .sync-time{margin-left:auto;color:var(--primary-mid);font-size:.78rem}
  .step-indicator{display:flex;gap:0;margin-bottom:22px}
  .step{flex:1;padding:10px 8px;text-align:center;font-size:.8rem;font-weight:600;border-bottom:3px solid var(--border);color:var(--muted);transition:all .2s}
  .step.active{border-color:var(--primary);color:var(--primary)}
  .step.done{border-color:var(--success);color:var(--success)}
  .csv-format-hint{background:#f2fbf7;border:1px solid #cdeee0;border-radius:8px;padding:14px;font-size:.8rem;font-family:monospace;overflow-x:auto;white-space:pre;margin-bottom:16px;line-height:1.6}
  .changes-summary{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px}
  .change-card{padding:12px;border-radius:8px;text-align:center}
  .change-card .num{font-size:1.6rem;font-weight:700}
  .change-card .lbl{font-size:.75rem;margin-top:2px}
  .c-new{background:#e6f4ec;color:#2d8a4e}
  .c-upd{background:#e3f7ef;color:#17956f}
  .c-unch{background:#f5f5f5;color:var(--muted)}
  .flex{display:flex}.items-center{align-items:center}.gap-2{gap:8px}.gap-3{gap:12px}
  .mt-2{margin-top:8px}.mt-4{margin-top:16px}.mb-3{margin-bottom:12px}
  .ml-auto{margin-left:auto}.font-bold{font-weight:700}.text-sm{font-size:.875rem}.text-muted{color:var(--muted)}
  .text-right{text-align:right}.text-center{text-align:center}
  .w-full{width:100%}
  .empty-state{text-align:center;padding:44px;color:var(--muted)}
  .empty-state .icon{font-size:2.8rem;margin-bottom:10px}
  .divider{border:none;border-top:1px solid var(--border);margin:16px 0}
  .info-box{background:#f2fbf7;border:1px solid #cdeee0;border-radius:8px;padding:12px 14px;font-size:.83rem;color:#17956f;line-height:1.5}
  .encoding-box{background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:14px;margin-bottom:18px;font-size:.85rem;color:#92400e}

  /* ── Edytor WYSIWYG ── */
  .rte-wrap{border:1.5px solid var(--border);border-radius:8px;overflow:hidden;background:#fff}
  .rte-toolbar{display:flex;align-items:center;gap:4px;flex-wrap:wrap;padding:8px;background:#f8fafc;border-bottom:1px solid var(--border)}
  .rte-btn{min-width:30px;height:30px;padding:0 7px;border:1.5px solid transparent;border-radius:6px;background:transparent;cursor:pointer;font-size:.85rem;color:#374151;display:inline-flex;align-items:center;justify-content:center}
  .rte-btn:hover{background:#e5e7eb}
  .rte-btn.active{background:var(--primary-light);border-color:var(--primary);color:var(--primary)}
  .rte-sep{width:1px;height:22px;background:var(--border);margin:0 3px}
  .rte-select{height:30px;border:1.5px solid var(--border);border-radius:6px;background:#fff;font-size:.78rem;padding:0 4px;max-width:110px}
  .rte-colors{display:flex;gap:4px;align-items:center}
  .rte-color-dot{width:18px;height:18px;border-radius:50%;border:1.5px solid #fff;box-shadow:0 0 0 1px var(--border);cursor:pointer;padding:0}
  .rte-color-dot:hover{transform:scale(1.15)}
  .rte-editor{min-height:220px;max-height:480px;overflow-y:auto;padding:14px;font-size:.9rem;line-height:1.6;outline:none}
  .rte-editor:empty:before{content:attr(data-placeholder);color:#9ca3af}
  .rte-editor img{max-width:100%;border-radius:6px;margin:6px 0}
  .rte-editor ul,.rte-editor ol{margin-left:22px}

  /* ── Strona szczegółów produktu ── */
  .product-link{color:inherit;text-decoration:none;cursor:pointer}
  .product-link:hover{color:var(--primary);text-decoration:underline}
  .pdp-breadcrumb{font-size:.85rem;color:var(--muted);margin-bottom:16px}
  .pdp-breadcrumb a{color:var(--primary);text-decoration:none;cursor:pointer}
  .pdp-breadcrumb a:hover{text-decoration:underline}
  .pdp-grid{display:grid;grid-template-columns:380px 1fr;gap:32px;align-items:start}
  @media (max-width: 860px){.pdp-grid{grid-template-columns:1fr}}
  .pdp-image-box{background:#f2fbf7;border:1px solid #cdeee0;border-radius:var(--radius);overflow:hidden;display:flex;align-items:center;justify-content:center;min-height:320px}
  .pdp-image-box img{width:100%;height:100%;object-fit:cover}
  .pdp-image-box .emoji-fallback{font-size:6rem}
  .pdp-title{font-size:1.5rem;font-weight:700;margin-bottom:8px}
  .pdp-price{font-size:1.8rem;font-weight:700;color:var(--primary);margin:14px 0}
  .pdp-section-title{font-size:1.1rem;font-weight:700;margin:28px 0 14px;border-bottom:2px solid var(--primary-light);padding-bottom:8px}
  .pdp-rich-content{font-size:.95rem;line-height:1.7;color:#333}
  .pdp-rich-content img{max-width:100%;border-radius:8px;margin:10px 0}
  .specs-table{width:100%;border-collapse:collapse;font-size:.88rem}
  .specs-table tr{border-bottom:1px solid var(--border)}
  .specs-table tr:last-child{border-bottom:none}
  .specs-table td{padding:10px 12px}
  .specs-table td:first-child{font-weight:600;color:#374151;width:40%;background:#f8fafc}
  .spec-row-editor{display:flex;gap:8px;align-items:center;margin-bottom:8px}
  .wfmag-badge{background:linear-gradient(90deg,#17956f,#1cb88a);color:#fff;border-radius:6px;padding:3px 9px;font-size:.72rem;font-weight:700;letter-spacing:.5px}

  /* ── Płatności ── */
  .pay-methods{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:18px}
  .pay-method{display:flex;flex-direction:column;align-items:center;gap:6px;padding:16px 10px;border:2px solid var(--border);border-radius:10px;background:#fff;cursor:pointer;transition:all .15s}
  .pay-method:hover{border-color:var(--primary-mid)}
  .pay-method.selected{border-color:var(--primary);background:var(--primary-light)}
  .pay-method-icon{font-size:1.8rem}
  .pay-method-label{font-size:.82rem;font-weight:600;color:#333}
  .pay-method-sub{font-size:.7rem;color:var(--muted)}
  .pay-summary{background:#f2fbf7;border:1px solid #cdeee0;border-radius:8px;padding:14px;margin-bottom:18px}
  .pay-summary-row{display:flex;justify-content:space-between;font-size:.9rem;padding:4px 0}
  .pay-summary-total{font-weight:700;font-size:1.1rem;color:var(--primary);border-top:1px solid #cdeee0;margin-top:6px;padding-top:8px}
  .blik-input{display:flex;gap:8px;justify-content:center;margin:16px 0}
  .blik-digit{width:42px;height:50px;text-align:center;font-size:1.3rem;font-weight:700;border:2px solid var(--border);border-radius:8px;outline:none}
  .blik-digit:focus{border-color:var(--primary)}
  .card-field-row{display:flex;gap:10px}
  .pay-processing{text-align:center;padding:30px 10px}
  .pay-spinner{width:48px;height:48px;border:4px solid #cdeee0;border-top-color:var(--primary);border-radius:50%;margin:0 auto 16px;animation:spin 0.8s linear infinite}
  @keyframes spin{to{transform:rotate(360deg)}}
  .pay-success{text-align:center;padding:20px 10px}
  .pay-success-icon{font-size:3.5rem;margin-bottom:10px}
  .secure-badge{display:flex;align-items:center;justify-content:center;gap:6px;font-size:.75rem;color:var(--muted);margin-top:14px}
`


// ── GŁÓWNA APLIKACJA ──────────────────────────────────────────────────────────
export default function App() {
  const [users, setUsers] = useState(INITIAL_USERS);
  const [products, setProducts] = useState(INITIAL_PRODUCTS);
  const [units, setUnits] = useState(DEFAULT_UNITS);
  const [categories, setCategories] = useState([
    { name: "Elektronika", subcategories: ["Laptopy", "Audio", "Smartwatche"] },
    { name: "Spożywcze", subcategories: [] },
    { name: "Sport", subcategories: ["Plecaki", "Odzież sportowa"] },
    { name: "Książki", subcategories: [] },
  ]);
  const [currentUser, setCurrentUser] = useState({ id: "guest-initial", name: "Gość", email: null, role: "guest", discount: 0 });
  const [page, setPage] = useState("shop");
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [alert, setAlert] = useState(null);
  const [modal, setModal] = useState(null);
  const [editItem, setEditItem] = useState(null);
  const [orders, setOrders] = useState([]);
  const [searchQ, setSearchQ] = useState("");
  const [filterCat, setFilterCat] = useState("Wszystkie");
  const [filterSubcat, setFilterSubcat] = useState("Wszystkie");
  const [lastSync, setLastSync] = useState(null);
  const [paymentOpen, setPaymentOpen] = useState(false);

  const showAlert = (msg, type = "success") => {
    setAlert({ msg, type });
    setTimeout(() => setAlert(null), 4000);
  };

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const isAdmin = currentUser?.role === "admin";
  const isGuest = currentUser?.role === "guest";
  const discount = currentUser?.discount || 0;

  const openProductDetail = (productId) => {
    setSelectedProductId(productId);
    setPage("product-detail");
  };

  const addToCart = (p) => {
    setCart(prev => {
      const ex = prev.find(i => i.id === p.id);
      if (ex) return prev.map(i => i.id === p.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { ...p, qty: 1 }];
    });
    showAlert(`Dodano "${p.name}" do koszyka`);
  };

  const updateQty = (id, delta) =>
    setCart(prev => prev.map(i => i.id === id ? { ...i, qty: Math.max(0, i.qty + delta) } : i).filter(i => i.qty > 0));

  const cartSub = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const cartDisc = cartSub * (discount / 100);
  const cartAfterDiscount = cartSub - cartDisc;
  const cartWeight = cart.reduce((s, i) => s + (i.weight || 0) * i.qty, 0);
  const shipment = classifyShipment(cart); // { type, label, count, totalWeight, baseCost, packages? }
  const freeShipping = cartAfterDiscount >= FREE_SHIPPING_THRESHOLD;
  const shippingCost = freeShipping ? 0 : shipment.baseCost;
  const cartTotal = cartAfterDiscount + shippingCost;
  const amountToFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - cartAfterDiscount);

  const placeOrder = (paymentMethod, paymentStatus, guestInfo) => {
    if (!cart.length) return;
    setOrders(prev => [{
      id: Date.now(), user: currentUser.name, userId: currentUser.id,
      guestEmail: guestInfo?.email || null,
      items: [...cart], subtotal: cartSub, discount, discountAmt: cartDisc,
      shipmentType: shipment.type, shipmentLabel: shipment.label, shippingCost, freeShipping,
      total: cartTotal, date: new Date().toLocaleDateString("pl-PL"),
      status: "Przyjęte", paymentMethod, paymentStatus,
    }, ...prev]);
    setCart([]); setCartOpen(false); setPaymentOpen(false);
    showAlert(paymentStatus === "Opłacone" ? "Płatność zaakceptowana — zamówienie złożone!" : "Zamówienie złożone — płatność przy odbiorze!");
  };

  const cats = ["Wszystkie", ...new Set([...categories.map(c => c.name), ...products.map(p => p.category)])];
  const filtered = products.filter(p =>
    (filterCat === "Wszystkie" || p.category === filterCat) &&
    (filterSubcat === "Wszystkie" || p.subcategory === filterSubcat) &&
    p.name.toLowerCase().includes(searchQ.toLowerCase())
  );

  if (!currentUser) return <><style>{css}</style><LoginPage users={users} setUsers={setUsers} onLogin={setCurrentUser} /></>;

  return (
    <>
      <style>{css}</style>
      <div className="app">
        <nav className="navbar">
          <div className="navbar-inner">
            <div className="navbar-brand"><img src={LOGO_TARFIX} alt="TARFIX" style={{ height: 34, verticalAlign: "middle" }} /></div>
            <div className="nav-left">
              <button className={`btn btn-ghost ${page === "shop" ? "active" : ""}`} onClick={() => setPage("shop")}>🏪 Sklep</button>
              {isAdmin && <>
                <button className={`btn btn-ghost ${page === "csv" ? "active" : ""}`} onClick={() => setPage("csv")}>📥 CSV</button>
                <button className={`btn btn-ghost ${page === "products" ? "active" : ""}`} onClick={() => setPage("products")}>📦 Produkty</button>
                <button className={`btn btn-ghost ${page === "users" ? "active" : ""}`} onClick={() => setPage("users")}>👥 Klienci</button>
                <button className={`btn btn-ghost ${page === "orders" ? "active" : ""}`} onClick={() => setPage("orders")}>📋 Zamówienia</button>
              </>}
              {!isAdmin && !isGuest && <button className={`btn btn-ghost ${page === "orders" ? "active" : ""}`} onClick={() => setPage("orders")}>📋 Zamówienia</button>}
            </div>
            <div className="nav-right">
              <button className="btn btn-ghost" onClick={() => setCartOpen(true)} style={{ position: "relative" }}>
                🛒 Koszyk {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
              </button>
              <span className="text-sm" style={{ color: "#93c5fd", whiteSpace: "nowrap" }}>{isGuest ? "🛍️ Gość" : `👤 ${currentUser.name}`}</span>
              {discount > 0 && <span className="badge badge-green">{discount}%</span>}
              <button className="btn btn-ghost" style={{ border: "1px solid rgba(255,255,255,.25)", borderRadius: 8 }} onClick={() => { setCurrentUser(null); setCart([]); setPage("shop"); }}>{isGuest ? "Zaloguj się" : "Wyloguj"}</button>
            </div>
          </div>
        </nav>

        <main className="main">
          {alert && <div className={`alert alert-${alert.type}`}>{alert.type === "success" ? "✅" : alert.type === "warning" ? "⚠️" : alert.type === "info" ? "ℹ️" : "❌"} {alert.msg}</div>}

          {isGuest && page === "shop" && (
            <div className="alert alert-info">
              🛍️ Robisz zakupy jako gość — Twoje zamówienie nie będzie zapisane na koncie.{" "}
              <a href="#" onClick={(e) => { e.preventDefault(); setCurrentUser(null); }} style={{ color: "var(--primary)", fontWeight: 600, textDecoration: "underline" }}>Załóż konto</a>, aby zyskać dostęp do historii zamówień i rabatów.
            </div>
          )}

          {lastSync && page !== "csv" && (
            <div className="sync-bar">
              <span>🔄 Ostatnia synchronizacja z WF-Mag:</span>
              <span style={{ color: "#6ee7b7" }}>{lastSync.file}</span>
              <span>— zaimportowano <strong>{lastSync.imported}</strong> produktów</span>
              <span className="sync-time">{lastSync.time}</span>
            </div>
          )}

          {page === "shop" && <ShopPage products={filtered} categories={cats} categoriesFull={categories} filterCat={filterCat} setFilterCat={setFilterCat} filterSubcat={filterSubcat} setFilterSubcat={setFilterSubcat} searchQ={searchQ} setSearchQ={setSearchQ} onAdd={addToCart} discount={discount} units={units} onOpenDetail={openProductDetail} />}
          {page === "product-detail" && <ProductDetailPage product={products.find(p => p.id === selectedProductId)} units={units} discount={discount} onAdd={addToCart} onBack={() => setPage("shop")} />}
          {page === "csv" && isAdmin && <CsvImportPage products={products} setProducts={setProducts} units={units} setUnits={setUnits} showAlert={showAlert} setLastSync={setLastSync} />}
          {page === "products" && isAdmin && <AdminProducts products={products} setProducts={setProducts} categories={categories} setCategories={setCategories} units={units} setUnits={setUnits} showAlert={showAlert} modal={modal} setModal={setModal} editItem={editItem} setEditItem={setEditItem} />}
          {page === "users" && isAdmin && <AdminUsers users={users} setUsers={setUsers} showAlert={showAlert} modal={modal} setModal={setModal} editItem={editItem} setEditItem={setEditItem} />}
          {page === "orders" && !isGuest && <OrdersPage orders={isAdmin ? orders : orders.filter(o => o.userId === currentUser.id)} isAdmin={isAdmin} units={units} />}
        </main>
      </div>

      {cartOpen && <div className="overlay" onClick={() => setCartOpen(false)} />}
      <div className={`cart-drawer ${cartOpen ? "open" : ""}`}>
        <div className="cart-header">
          <h2 className="card-title" style={{ margin: 0 }}>🛒 Koszyk ({cartCount})</h2>
          <button className="close-btn" onClick={() => setCartOpen(false)}>✕</button>
        </div>
        <div className="cart-items">
          {cart.length === 0 ? <div className="empty-state"><div className="icon">🛒</div>Koszyk jest pusty</div>
            : cart.map(item => (
              <div key={item.id} className="cart-item">
                <span className="cart-item-emoji">{item.photo ? <img src={item.photo} alt={item.name} className="cart-item-photo" /> : item.image}</span>
                <div className="cart-item-info">
                  <div className="cart-item-name">{item.name}</div>
                  <div className="cart-item-price">{fmt(item.price)} / szt.</div>
                  <div className="cart-qty">
                    <button className="qty-btn" onClick={() => updateQty(item.id, -1)}>−</button>
                    <span className="qty-val">{item.qty}</span>
                    <button className="qty-btn" onClick={() => updateQty(item.id, 1)}>+</button>
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div className="font-bold" style={{ color: "var(--primary)", fontSize: ".9rem" }}>{fmt(item.price * item.qty)}</div>
                </div>
              </div>
            ))}
        </div>
        <div className="cart-footer">
          {cart.length > 0 && (
            <div className="shipping-info-box">
              <div className="flex items-center gap-2" style={{ marginBottom: 6 }}>
                <span>{shipment.type === "packages" ? "📦" : "🪵"} {shipment.label}</span>
                <span className="text-muted">· {cartWeight.toFixed(1)} kg łącznie</span>
              </div>
              {freeShipping
                ? <div className="text-sm" style={{ color: "var(--success)", fontWeight: 600 }}>🚚 Darmowa dostawa!</div>
                : <>
                  <div className="text-sm text-muted">Brakuje {fmt(amountToFreeShipping)} do darmowej dostawy</div>
                  <div className="shipping-progress"><div className="shipping-progress-bar" style={{ width: `${Math.min(100, (cartAfterDiscount / FREE_SHIPPING_THRESHOLD) * 100)}%` }}></div></div>
                </>}
            </div>
          )}
          {discount > 0 && <div className="discount-box">🎉 Rabat {discount}% — oszczędzasz {fmt(cartDisc)}</div>}
          <div className="cart-total-row"><span>Suma:</span><span>{fmt(cartSub)}</span></div>
          {discount > 0 && <div className="cart-total-row" style={{ color: "var(--success)" }}><span>Rabat ({discount}%):</span><span>−{fmt(cartDisc)}</span></div>}
          <div className="cart-total-row">
            <span>Dostawa ({shipment.label}):</span>
            <span>{freeShipping ? <span style={{ color: "var(--success)", fontWeight: 600 }}>Gratis</span> : fmt(shippingCost)}</span>
          </div>
          <div className="cart-total-row cart-total-final"><span>Do zapłaty:</span><span>{fmt(cartTotal)}</span></div>
          <button className="btn btn-success w-full" style={{ marginTop: 10 }} onClick={() => setPaymentOpen(true)} disabled={!cart.length}>💳 Przejdź do płatności</button>
        </div>
      </div>

      {paymentOpen && (
        <PaymentModal
          total={cartTotal}
          subtotal={cartAfterDiscount}
          shippingCost={shippingCost}
          freeShipping={freeShipping}
          shipmentLabel={shipment.label}
          isGuest={isGuest}
          onClose={() => setPaymentOpen(false)}
          onComplete={placeOrder}
        />
      )}
    </>
  );
}

// ── LOGOWANIE ─────────────────────────────────────────────────────────────────
function LoginPage({ users, setUsers, onLogin }) {
  const [tab, setTab] = useState("login"); // login | register
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");

  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPass, setRegPass] = useState("");
  const [regPass2, setRegPass2] = useState("");
  const [regErr, setRegErr] = useState("");

  const handleLogin = () => {
    const u = users.find(u => u.email === email && u.password === password);
    if (u) onLogin(u); else setErr("Nieprawidłowy email lub hasło.");
  };

  const handleRegister = () => {
    setRegErr("");
    if (!regName.trim() || !regEmail.trim() || !regPass) return setRegErr("Wypełnij wszystkie pola.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(regEmail)) return setRegErr("Podaj poprawny adres e-mail.");
    if (regPass.length < 6) return setRegErr("Hasło musi mieć min. 6 znaków.");
    if (regPass !== regPass2) return setRegErr("Hasła nie są identyczne.");
    if (users.some(u => u.email.toLowerCase() === regEmail.toLowerCase())) return setRegErr("Konto z tym adresem e-mail już istnieje.");
    const newUser = { id: Date.now(), name: regName.trim(), email: regEmail.trim(), password: regPass, role: "customer", discount: 0 };
    setUsers(prev => [...prev, newUser]);
    onLogin(newUser);
  };

  const handleGuest = () => {
    onLogin({ id: "guest-" + Date.now(), name: "Gość", email: null, role: "guest", discount: 0 });
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-title"><img src={LOGO_TARFIX} alt="TARFIX" style={{ height: 42, margin: "0 auto", display: "block" }} /></div>
        <div className="login-sub">{tab === "login" ? "Zaloguj się do swojego konta" : "Załóż nowe konto"}</div>

        <div className="login-tabs" style={{ marginBottom: 18 }}>
          <button className={`login-tab ${tab === "login" ? "active" : ""}`} onClick={() => { setTab("login"); setErr(""); }}>Logowanie</button>
          <button className={`login-tab ${tab === "register" ? "active" : ""}`} onClick={() => { setTab("register"); setRegErr(""); }}>Nowe konto</button>
        </div>

        {tab === "login" && (
          <>
            {err && <div className="alert alert-danger">❌ {err}</div>}
            <div className="form-group"><label className="form-label">E-mail</label>
              <input className="form-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="jan@example.com" /></div>
            <div className="form-group"><label className="form-label">Hasło</label>
              <input className="form-input" type="password" value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => e.key === "Enter" && handleLogin()} placeholder="••••••••" /></div>
            <button className="btn btn-primary w-full" style={{ padding: "11px" }} onClick={handleLogin}>Zaloguj się →</button>

            <div className="flex items-center gap-2 mt-4" style={{ margin: "18px 0" }}>
              <div style={{ flex: 1, height: 1, background: "var(--border)" }}></div>
              <span className="text-sm text-muted">lub</span>
              <div style={{ flex: 1, height: 1, background: "var(--border)" }}></div>
            </div>
            <button className="btn btn-secondary w-full" onClick={handleGuest}>🛍️ Kontynuuj jako gość</button>

            <div style={{ marginTop: 18, background: "#f8fafc", borderRadius: 8, padding: 12 }}>
              <p className="text-sm text-muted" style={{ marginBottom: 5, fontWeight: 600 }}>Konta testowe:</p>
              <p className="text-sm text-muted">🔧 admin@sklep.pl / admin123</p>
              <p className="text-sm text-muted">👤 jan@example.com / haslo123 (−10%)</p>
              <p className="text-sm text-muted">👤 anna@example.com / haslo123 (−5%)</p>
            </div>
          </>
        )}

        {tab === "register" && (
          <>
            {regErr && <div className="alert alert-danger">❌ {regErr}</div>}
            <div className="form-group"><label className="form-label">Imię i nazwisko</label>
              <input className="form-input" value={regName} onChange={e => setRegName(e.target.value)} placeholder="Jan Kowalski" /></div>
            <div className="form-group"><label className="form-label">E-mail</label>
              <input className="form-input" type="email" value={regEmail} onChange={e => setRegEmail(e.target.value)} placeholder="jan@example.com" /></div>
            <div className="form-group"><label className="form-label">Hasło</label>
              <input className="form-input" type="password" value={regPass} onChange={e => setRegPass(e.target.value)} placeholder="min. 6 znaków" /></div>
            <div className="form-group"><label className="form-label">Powtórz hasło</label>
              <input className="form-input" type="password" value={regPass2} onChange={e => setRegPass2(e.target.value)} onKeyDown={e => e.key === "Enter" && handleRegister()} placeholder="••••••••" /></div>
            <button className="btn btn-primary w-full" style={{ padding: "11px" }} onClick={handleRegister}>Załóż konto →</button>
            <p className="text-sm text-muted text-center mt-2" style={{ marginTop: 10 }}>Zakładając konto otrzymasz dostęp do historii zamówień i przyszłych rabatów.</p>
          </>
        )}
      </div>
    </div>
  );
}

// ── PŁATNOŚĆ ──────────────────────────────────────────────────────────────────
// ── EDYTOR WYSIWYG (własny, lekki, bez zewnętrznych zależności) ──────────────
function RichTextEditor({ value, onChange, placeholder }) {
  const editorRef = useRef(null);
  const fileRef = useRef(null);
  const [activeFormats, setActiveFormats] = useState({});
  const savedSelection = useRef(null);

  // Synchronizuje DOM z value tylko gdy zmiana przychodzi z zewnątrz (np. przy edycji innego produktu)
  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== (value || "")) {
      editorRef.current.innerHTML = value || "";
    }
  }, [value]);

  const exec = (cmd, arg = null) => {
    editorRef.current?.focus();
    document.execCommand(cmd, false, arg);
    onChange(editorRef.current?.innerHTML || "");
    updateActiveFormats();
  };

  const updateActiveFormats = () => {
    setActiveFormats({
      bold: document.queryCommandState("bold"),
      italic: document.queryCommandState("italic"),
      underline: document.queryCommandState("underline"),
      justifyLeft: document.queryCommandState("justifyLeft"),
      justifyCenter: document.queryCommandState("justifyCenter"),
      justifyRight: document.queryCommandState("justifyRight"),
      insertUnorderedList: document.queryCommandState("insertUnorderedList"),
      insertOrderedList: document.queryCommandState("insertOrderedList"),
    });
  };

  const handleInput = () => onChange(editorRef.current?.innerHTML || "");

  const handleColor = (color) => exec("foreColor", color);

  const handleFontSize = (size) => {
    // execCommand fontSize tylko obsługuje 1-7, mapujemy na realne px przez span
    editorRef.current?.focus();
    document.execCommand("fontSize", false, "7");
    const fontElements = editorRef.current.querySelectorAll('font[size="7"]');
    fontElements.forEach(el => {
      el.removeAttribute("size");
      el.style.fontSize = size;
    });
    onChange(editorRef.current?.innerHTML || "");
  };

  const handleFontFamily = (font) => exec("fontName", font);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) return;
    if (file.size > 3 * 1024 * 1024) { alert("Obraz jest większy niż 3 MB"); return; }
    const reader = new FileReader();
    reader.onload = () => {
      editorRef.current?.focus();
      document.execCommand("insertImage", false, reader.result);
      onChange(editorRef.current?.innerHTML || "");
    };
    reader.readAsDataURL(file);
  };

  const colors = ["#1c1c1c", "#dc2626", "#e85d04", "#ca8a04", "#16a34a", "#1cb88a", "#0369a1", "#7c3aed"];
  const fonts = [
    { value: "Inter, sans-serif", label: "Inter (domyślna)" },
    { value: "Georgia, serif", label: "Georgia" },
    { value: "'Courier New', monospace", label: "Courier" },
    { value: "Verdana, sans-serif", label: "Verdana" },
    { value: "'Times New Roman', serif", label: "Times New Roman" },
  ];
  const sizes = [
    { value: "13px", label: "Mały" },
    { value: "16px", label: "Normalny" },
    { value: "20px", label: "Duży" },
    { value: "28px", label: "Bardzo duży" },
  ];

  return (
    <div className="rte-wrap">
      <div className="rte-toolbar">
        <button type="button" className={`rte-btn ${activeFormats.bold ? "active" : ""}`} onClick={() => exec("bold")} title="Pogrubienie"><strong>B</strong></button>
        <button type="button" className={`rte-btn ${activeFormats.italic ? "active" : ""}`} onClick={() => exec("italic")} title="Kursywa"><em>I</em></button>
        <button type="button" className={`rte-btn ${activeFormats.underline ? "active" : ""}`} onClick={() => exec("underline")} title="Podkreślenie"><u>U</u></button>
        <span className="rte-sep"></span>
        <select className="rte-select" onChange={e => handleFontFamily(e.target.value)} defaultValue="" title="Czcionka">
          <option value="" disabled>Czcionka</option>
          {fonts.map(f => <option key={f.value} value={f.value} style={{ fontFamily: f.value }}>{f.label}</option>)}
        </select>
        <select className="rte-select" onChange={e => handleFontSize(e.target.value)} defaultValue="" title="Rozmiar tekstu">
          <option value="" disabled>Rozmiar</option>
          {sizes.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
        <span className="rte-sep"></span>
        <div className="rte-colors">
          {colors.map(c => <button type="button" key={c} className="rte-color-dot" style={{ background: c }} onClick={() => handleColor(c)} title={`Kolor tekstu: ${c}`} />)}
        </div>
        <span className="rte-sep"></span>
        <button type="button" className={`rte-btn ${activeFormats.justifyLeft ? "active" : ""}`} onClick={() => exec("justifyLeft")} title="Do lewej">⬅</button>
        <button type="button" className={`rte-btn ${activeFormats.justifyCenter ? "active" : ""}`} onClick={() => exec("justifyCenter")} title="Do środka">↔</button>
        <button type="button" className={`rte-btn ${activeFormats.justifyRight ? "active" : ""}`} onClick={() => exec("justifyRight")} title="Do prawej">➡</button>
        <span className="rte-sep"></span>
        <button type="button" className={`rte-btn ${activeFormats.insertUnorderedList ? "active" : ""}`} onClick={() => exec("insertUnorderedList")} title="Lista punktowana">• ‒</button>
        <button type="button" className={`rte-btn ${activeFormats.insertOrderedList ? "active" : ""}`} onClick={() => exec("insertOrderedList")} title="Lista numerowana">1.</button>
        <span className="rte-sep"></span>
        <button type="button" className="rte-btn" onClick={() => fileRef.current?.click()} title="Wstaw obraz">🖼️</button>
        <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handleImageUpload} />
        <button type="button" className="rte-btn" onClick={() => exec("removeFormat")} title="Wyczyść formatowanie">✕</button>
      </div>
      <div
        ref={editorRef}
        className="rte-editor"
        contentEditable
        onInput={handleInput}
        onMouseUp={updateActiveFormats}
        onKeyUp={updateActiveFormats}
        data-placeholder={placeholder || "Wpisz rozszerzony opis produktu..."}
        suppressContentEditableWarning
      />
    </div>
  );
}


function PaymentModal({ total, subtotal, shippingCost, freeShipping, shipmentLabel, isGuest, onClose, onComplete }) {
  const [method, setMethod] = useState("card");
  const [stage, setStage] = useState("select"); // select | form | processing | success
  const [card, setCard] = useState({ number: "", expiry: "", cvc: "", name: "" });
  const [blik, setBlik] = useState(["", "", "", "", "", ""]);
  const [guestEmail, setGuestEmail] = useState("");
  const [guestEmailErr, setGuestEmailErr] = useState("");
  const blikRefs = useRef([]);

  const methods = [
    { id: "card", icon: "💳", label: "Karta płatnicza", sub: "Visa, Mastercard" },
    { id: "blik", icon: "📱", label: "BLIK", sub: "Kod z aplikacji banku" },
    { id: "transfer", icon: "🏦", label: "Przelew online", sub: "Szybki przelew" },
    { id: "cod", icon: "📦", label: "Za pobraniem", sub: "Płatność przy odbiorze" },
  ];

  const formatCardNumber = (v) => v.replace(/\D/g, "").slice(0, 16).replace(/(\d{4})(?=\d)/g, "$1 ").trim();
  const formatExpiry = (v) => v.replace(/\D/g, "").slice(0, 4).replace(/(\d{2})(?=\d)/, "$1/");

  const handleBlikChange = (i, val) => {
    if (!/^\d?$/.test(val)) return;
    const next = [...blik]; next[i] = val; setBlik(next);
    if (val && i < 5) blikRefs.current[i + 1]?.focus();
  };

  const guestEmailValid = !isGuest || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(guestEmail);

  const canSubmit = () => {
    if (!guestEmailValid) return false;
    if (method === "cod") return true;
    if (method === "blik") return blik.every(d => d !== "");
    if (method === "card") return card.number.replace(/\s/g, "").length === 16 && card.expiry.length === 5 && card.cvc.length >= 3 && card.name.trim();
    if (method === "transfer") return true;
    return false;
  };

  const submit = () => {
    if (isGuest && !guestEmailValid) { setGuestEmailErr("Podaj poprawny adres e-mail."); return; }
    const guestInfo = isGuest ? { email: guestEmail } : null;
    if (method === "cod") return onComplete("Za pobraniem", "Do zapłaty przy odbiorze", guestInfo);
    setStage("processing");
    setTimeout(() => {
      setStage("success");
      setTimeout(() => {
        const labelMap = { card: "Karta płatnicza", blik: "BLIK", transfer: "Przelew online" };
        onComplete(labelMap[method], "Opłacone", guestInfo);
      }, 1200);
    }, 1800);
  };

  return (
    <div className="modal-bg">
      <div className="modal" style={{ maxWidth: 460 }}>
        <div className="modal-header">
          <h2 className="modal-title">💳 Płatność</h2>
          {stage !== "processing" && <button className="close-btn" onClick={onClose}>✕</button>}
        </div>
        <div className="modal-body">

          {stage === "processing" && (
            <div className="pay-processing">
              <div className="pay-spinner"></div>
              <p className="font-bold">Przetwarzanie płatności...</p>
              <p className="text-sm text-muted mt-2">Nie zamykaj tego okna</p>
            </div>
          )}

          {stage === "success" && (
            <div className="pay-success">
              <div className="pay-success-icon">✅</div>
              <p className="font-bold" style={{ fontSize: "1.1rem" }}>Płatność zaakceptowana!</p>
              <p className="text-sm text-muted mt-2">Kwota: {fmt(total)}</p>
            </div>
          )}

          {(stage === "select" || stage === "form") && (
            <>
              <div className="pay-summary">
                <div className="pay-summary-row"><span>Wartość produktów:</span><span>{fmt(subtotal)}</span></div>
                <div className="pay-summary-row"><span>Dostawa ({shipmentLabel}):</span><span>{freeShipping ? <span style={{ color: "var(--success)", fontWeight: 600 }}>Gratis</span> : fmt(shippingCost)}</span></div>
                <div className="pay-summary-row pay-summary-total"><span>Razem</span><span>{fmt(total)}</span></div>
              </div>

              {isGuest && (
                <div className="form-group">
                  <label className="form-label">E-mail do potwierdzenia zamówienia *</label>
                  <input className="form-input" type="email" placeholder="twoj@email.pl" value={guestEmail}
                    onChange={e => { setGuestEmail(e.target.value); setGuestEmailErr(""); }} />
                  {guestEmailErr && <p className="text-sm" style={{ color: "var(--danger)", marginTop: 4 }}>{guestEmailErr}</p>}
                </div>
              )}

              <p className="form-label mb-3">Wybierz metodę płatności:</p>
              <div className="pay-methods">
                {methods.map(m => (
                  <div key={m.id} className={`pay-method ${method === m.id ? "selected" : ""}`} onClick={() => setMethod(m.id)}>
                    <span className="pay-method-icon">{m.icon}</span>
                    <span className="pay-method-label">{m.label}</span>
                    <span className="pay-method-sub">{m.sub}</span>
                  </div>
                ))}
              </div>

              {method === "card" && (
                <>
                  <div className="form-group">
                    <label className="form-label">Numer karty</label>
                    <input className="form-input" placeholder="1234 5678 9012 3456" value={card.number}
                      onChange={e => setCard(c => ({ ...c, number: formatCardNumber(e.target.value) }))} maxLength={19} />
                  </div>
                  <div className="card-field-row">
                    <div className="form-group" style={{ flex: 1 }}>
                      <label className="form-label">Data ważności</label>
                      <input className="form-input" placeholder="MM/RR" value={card.expiry}
                        onChange={e => setCard(c => ({ ...c, expiry: formatExpiry(e.target.value) }))} maxLength={5} />
                    </div>
                    <div className="form-group" style={{ flex: 1 }}>
                      <label className="form-label">CVC</label>
                      <input className="form-input" placeholder="123" value={card.cvc}
                        onChange={e => setCard(c => ({ ...c, cvc: e.target.value.replace(/\D/g, "").slice(0, 3) }))} maxLength={3} />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Imię i nazwisko na karcie</label>
                    <input className="form-input" placeholder="JAN KOWALSKI" value={card.name}
                      onChange={e => setCard(c => ({ ...c, name: e.target.value.toUpperCase() }))} />
                  </div>
                </>
              )}

              {method === "blik" && (
                <div className="text-center">
                  <p className="text-sm text-muted">Wpisz 6-cyfrowy kod BLIK z aplikacji bankowej</p>
                  <div className="blik-input">
                    {blik.map((d, i) => (
                      <input key={i} ref={el => blikRefs.current[i] = el} className="blik-digit" value={d}
                        onChange={e => handleBlikChange(i, e.target.value)} maxLength={1} inputMode="numeric" />
                    ))}
                  </div>
                </div>
              )}

              {method === "transfer" && (
                <div className="info-box">
                  Po kliknięciu "Zapłać" zostaniesz przekierowany do bezpiecznego serwisu Twojego banku, aby autoryzować przelew.
                </div>
              )}

              {method === "cod" && (
                <div className="info-box">
                  Zapłacisz gotówką lub kartą kurierowi przy odbiorze przesyłki. Może obowiązywać dodatkowa opłata za pobranie.
                </div>
              )}

              <button className="btn btn-success w-full mt-4" onClick={submit} disabled={!canSubmit()}>
                🔒 Zapłać {fmt(total)}
              </button>
              <div className="secure-badge">🔒 Połączenie szyfrowane SSL · Twoje dane są bezpieczne</div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}


function ShopPage({ products, categories, categoriesFull, filterCat, setFilterCat, filterSubcat, setFilterSubcat, searchQ, setSearchQ, onAdd, discount, units, onOpenDetail }) {
  const selectCategory = (c) => {
    setFilterCat(c);
    setFilterSubcat("Wszystkie"); // reset podkategorii przy zmianie kategorii głównej
  };

  const activeSubcats = categoriesFull.find(c => c.name === filterCat)?.subcategories || [];

  return (
    <>
      <div className="page-header">
        <h1 className="page-title">🏪 Sklep</h1>
        {discount > 0 && <span className="badge badge-green" style={{ fontSize: ".85rem", padding: "5px 12px" }}>🎉 Twój rabat: {discount}%</span>}
      </div>
      <div className="search-bar">
        <input className="form-input" placeholder="🔍 Szukaj..." value={searchQ} onChange={e => setSearchQ(e.target.value)} />
        <div className="tabs" style={{ margin: 0, flex: 1 }}>
          {categories.map(c => <button key={c} className={`tab ${filterCat === c ? "active" : ""}`} onClick={() => selectCategory(c)}>{c}</button>)}
        </div>
      </div>
      {activeSubcats.length > 0 && (
        <div className="tabs subcat-tabs">
          <button className={`tab tab-sub ${filterSubcat === "Wszystkie" ? "active" : ""}`} onClick={() => setFilterSubcat("Wszystkie")}>Wszystkie</button>
          {activeSubcats.map(s => <button key={s} className={`tab tab-sub ${filterSubcat === s ? "active" : ""}`} onClick={() => setFilterSubcat(s)}>{s}</button>)}
        </div>
      )}
      {products.length === 0
        ? <div className="empty-state"><div className="icon">📦</div>Brak produktów</div>
        : <div className="products-grid">
          {products.map(p => {
            const dp = p.price * (1 - discount / 100);
            return (
              <div key={p.id} className="product-card">
                <div className="product-emoji">{p.photo ? <img src={p.photo} alt={p.name} className="product-photo" /> : p.image}</div>
                <div className="product-body">
                  <div className="product-name"><a className="product-link" onClick={() => onOpenDetail(p.id)}>{p.name}</a></div>
                  <div className="flex gap-2 items-center" style={{ flexWrap: "wrap" }}>
                    <span className="tag">{p.category}</span>
                    {p.subcategory && <span className="tag tag-sub">{p.subcategory}</span>}
                    {p.sku && <span className="product-sku">{p.sku}</span>}
                  </div>
                  <div className="product-desc">{p.description}</div>
                  <div>
                    {discount > 0 ? <>
                      <span className="product-price-original">{fmt(p.price)}</span>{" "}
                      <span className="product-price">{fmt(dp)}</span>
                      <div className="product-price-discount">Oszczędzasz {fmt(p.price - dp)}</div>
                    </> : <span className="product-price">{fmt(p.price)}</span>}
                  </div>
                  <div className="text-sm text-muted">Magazyn: <strong>{p.stock}</strong> {units.find(u => u.value === p.unit)?.label || "szt."}</div>
                </div>
                <div className="product-footer">
                  <button className="btn btn-primary w-full" onClick={() => onAdd(p)} disabled={p.stock === 0}>
                    {p.stock === 0 ? "Brak w magazynie" : "🛒 Dodaj"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>}
    </>
  );
}

// ── IMPORT CSV (główna nowość) ─────────────────────────────────────────────────
// ── STRONA SZCZEGÓŁÓW PRODUKTU ────────────────────────────────────────────────
function ProductDetailPage({ product, units, discount, onAdd, onBack }) {
  if (!product) {
    return (
      <div className="empty-state">
        <div className="icon">❓</div>
        Produkt nie został znaleziony.
        <div className="mt-4"><button className="btn btn-primary" onClick={onBack}>← Wróć do sklepu</button></div>
      </div>
    );
  }

  const discountedPrice = product.price * (1 - discount / 100);
  const unitLabel = units.find(u => u.value === product.unit)?.label || "szt.";

  return (
    <>
      <div className="pdp-breadcrumb">
        <a onClick={onBack}>🏪 Sklep</a> / <span className="tag">{product.category}</span>
        {product.subcategory && <> / <span className="tag tag-sub">{product.subcategory}</span></>}
        {" / "}<strong>{product.name}</strong>
      </div>

      <div className="pdp-grid">
        <div className="pdp-image-box">
          {product.photo
            ? <img src={product.photo} alt={product.name} />
            : <span className="emoji-fallback">{product.image}</span>}
        </div>

        <div>
          <h1 className="pdp-title">{product.name}</h1>
          <div className="flex gap-2 items-center" style={{ flexWrap: "wrap", marginBottom: 6 }}>
            <span className="tag">{product.category}</span>
            {product.subcategory && <span className="tag tag-sub">{product.subcategory}</span>}
            {product.sku && <span className="product-sku">{product.sku}</span>}
          </div>
          <p className="text-muted">{product.description}</p>

          <div className="pdp-price">
            {discount > 0 ? (
              <>
                <span className="product-price-original" style={{ fontSize: "1.1rem" }}>{fmt(product.price)}</span>{" "}
                {fmt(discountedPrice)}
                <div className="product-price-discount" style={{ fontSize: ".9rem" }}>🎉 Twój rabat {discount}% — oszczędzasz {fmt(product.price - discountedPrice)}</div>
              </>
            ) : fmt(product.price)}
          </div>

          <p className="text-sm text-muted">Magazyn: <strong>{product.stock}</strong> {unitLabel}{product.weight ? ` · waga: ${product.weight} kg/${unitLabel === "kg" ? "kg" : "szt."}` : ""}</p>

          <button className="btn btn-primary" style={{ marginTop: 16, padding: "12px 28px", fontSize: "1rem" }} onClick={() => onAdd(product)} disabled={product.stock === 0}>
            {product.stock === 0 ? "Brak w magazynie" : "🛒 Dodaj do koszyka"}
          </button>

          {product.longDescription && (
            <>
              <h2 className="pdp-section-title">Opis produktu</h2>
              <div className="pdp-rich-content" dangerouslySetInnerHTML={{ __html: product.longDescription }} />
            </>
          )}

          {product.specs && product.specs.filter(s => s.key).length > 0 && (
            <>
              <h2 className="pdp-section-title">Specyfikacja techniczna</h2>
              <table className="specs-table">
                <tbody>
                  {product.specs.filter(s => s.key).map((s, i) => (
                    <tr key={i}><td>{s.key}</td><td>{s.value}</td></tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
        </div>
      </div>
    </>
  );
}


function CsvImportPage({ products, setProducts, units, setUnits, showAlert, setLastSync }) {
  const [step, setStep] = useState(1); // 1=wgraj 2=mapuj 3=podgląd 4=wynik
  const [rawData, setRawData] = useState(null);   // sparsowane wiersze CSV
  const [csvHeaders, setCsvHeaders] = useState([]); // nagłówki z CSV
  const [mapping, setMapping] = useState(DEFAULT_MAPPING);
  const [preview, setPreview] = useState([]);     // przetworzone produkty
  const [result, setResult] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [fileName, setFileName] = useState("");
  const [encoding, setEncoding] = useState("auto"); // auto / UTF-8 / windows-1250
  const [detectedEncoding, setDetectedEncoding] = useState(null);
  const [pendingFile, setPendingFile] = useState(null);
  const [pendingNewUnits, setPendingNewUnits] = useState([]);
  const fileRef = useRef();

  const FIELDS = [
    { key: "sku", label: "Indeks / SKU", required: true },
    { key: "name", label: "Nazwa towaru", required: true },
    { key: "category", label: "Kategoria", required: false },
    { key: "price", label: "Cena (brutto)", required: true },
    { key: "stock", label: "Stan magazynowy", required: true },
    { key: "unit", label: "Jednostka miary", required: false },
    { key: "description", label: "Opis", required: false },
  ];

  // Wykrywa, czy bajty pliku wyglądają na prawidłowy UTF-8.
  // Polskie znaki w UTF-8 to 2-bajtowe sekwencje (np. "ą" = 0xC4 0x85).
  // Jeśli dekodowanie jako UTF-8 produkuje znak zamiany "�" (U+FFFD), to NIE jest UTF-8.
  const detectEncoding = (bytes) => {
    const utf8Text = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    if (!utf8Text.includes("\uFFFD")) return "UTF-8";
    return "windows-1250"; // niemal zawsze tak eksportuje WF-Mag i inne polskie programy
  };

  const decodeAndParse = (file, forcedEncoding) => {
    const reader = new FileReader();
    reader.onload = () => {
      const bytes = new Uint8Array(reader.result);
      const usedEncoding = forcedEncoding && forcedEncoding !== "auto" ? forcedEncoding : detectEncoding(bytes);
      setDetectedEncoding(usedEncoding);
      let text;
      try {
        text = new TextDecoder(usedEncoding).decode(bytes);
      } catch {
        text = new TextDecoder("utf-8").decode(bytes);
      }
      Papa.parse(text, {
        header: true,
        delimiter: ";",
        skipEmptyLines: true,
        complete: (res) => {
          if (!res.data.length) { showAlert("Plik CSV jest pusty lub niepoprawny", "danger"); return; }
          const headers = Object.keys(res.data[0]);
          setCsvHeaders(headers);
          setRawData(res.data);
          const autoMap = { ...DEFAULT_MAPPING };
          FIELDS.forEach(f => {
            const match = headers.find(h =>
              h.toLowerCase().includes(f.key) ||
              h.toLowerCase().includes(f.label.toLowerCase().split(" ")[0].toLowerCase())
            );
            if (match) autoMap[f.key] = match;
            else if (!headers.includes(autoMap[f.key])) autoMap[f.key] = headers[0] || "";
          });
          setMapping(autoMap);
          setStep(2);
        },
        error: () => showAlert("Błąd odczytu pliku CSV", "danger"),
      });
    };
    reader.onerror = () => showAlert("Nie udało się wczytać pliku", "danger");
    reader.readAsArrayBuffer(file);
  };

  const parseFile = (file) => {
    setFileName(file.name);
    setPendingFile(file);
    decodeAndParse(file, encoding);
  };

  const reparseWithEncoding = (newEncoding) => {
    setEncoding(newEncoding);
    if (pendingFile) decodeAndParse(pendingFile, newEncoding);
  };

  const handleDrop = useCallback((e) => {
    e.preventDefault(); setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file && (file.name.endsWith(".csv") || file.type === "text/csv")) parseFile(file);
    else showAlert("Proszę wgrać plik .csv", "warning");
  }, []);

  const handleFile = (e) => {
    const file = e.target.files[0];
    if (file) parseFile(file);
  };

  // Próbuje dopasować jednostkę z CSV do istniejącej (po aliasach lub dokładnej nazwie/symbolu).
  // Jeśli nic nie pasuje, zwraca null — sygnał, że trzeba założyć nową jednostkę.
  const resolveUnit = (rawValue) => {
    const v = String(rawValue || "").trim().toLowerCase();
    if (!v) return { value: "szt", isNew: false }; // brak danych w CSV -> domyślnie sztuka
    const aliasTarget = UNIT_ALIASES[v];
    if (aliasTarget) {
      const existing = units.find(u => u.value === aliasTarget);
      if (existing) return { value: existing.value, isNew: false };
    }
    // sprawdź czy coś już dokładnie odpowiada wartości (po symbolu lub nazwie)
    const exact = units.find(u => u.value.toLowerCase() === v || u.label.toLowerCase() === v);
    if (exact) return { value: exact.value, isNew: false };
    // nic nie znaleziono -> nowa jednostka, używamy oryginalnego tekstu z CSV jako symbolu i etykiety
    const newValue = aliasTarget || v;
    return { value: newValue, isNew: true, label: String(rawValue).trim() };
  };

  const buildPreview = () => {
    if (!rawData) return;
    const newUnitsFound = new Map(); // value -> label, zbieramy unikalne nowe jednostki z całego pliku
    const rows = rawData.map((row, idx) => {
      const sku = String(row[mapping.sku] || "").trim();
      const name = String(row[mapping.name] || "").trim();
      const category = String(row[mapping.category] || "Inne").trim();
      const price = parseNum(row[mapping.price]);
      const stock = Math.round(parseNum(row[mapping.stock]));
      const description = String(row[mapping.description] || "").trim();
      const unitRaw = mapping.unit ? row[mapping.unit] : "";
      const resolvedUnit = resolveUnit(unitRaw);
      if (resolvedUnit.isNew) newUnitsFound.set(resolvedUnit.value, resolvedUnit.label);
      const existing = products.find(p => p.sku === sku);
      let status = "new";
      if (existing) {
        status = (existing.price !== price || existing.stock !== stock || existing.name !== name || existing.unit !== resolvedUnit.value) ? "update" : "unchanged";
      }
      return { idx, sku, name, category, price, stock, description, unit: resolvedUnit.value, unitIsNew: resolvedUnit.isNew, status, existing };
    }).filter(r => r.name && r.price > 0);
    setPreview(rows);
    setPendingNewUnits([...newUnitsFound.entries()].map(([value, label]) => ({ value, label })));
    setStep(3);
  };

  const doImport = () => {
    // Najpierw rejestrujemy w systemie wszystkie nowe jednostki znalezione w pliku
    if (pendingNewUnits.length > 0) {
      setUnits(prev => {
        const existingValues = new Set(prev.map(u => u.value));
        const toAdd = pendingNewUnits.filter(u => !existingValues.has(u.value));
        return [...prev, ...toAdd];
      });
    }
    const newProds = [...products];
    let added = 0, updated = 0, unchanged = 0;
    preview.forEach(row => {
      if (row.status === "unchanged") { unchanged++; return; }
      const prod = {
        id: row.existing?.id || Date.now() + Math.random(),
        sku: row.sku,
        name: row.name,
        category: row.category,
        price: row.price,
        stock: row.stock,
        unit: row.unit,
        description: row.description,
        image: getEmoji(row.category),
      };
      if (row.status === "new") { newProds.push(prod); added++; }
      else {
        const i = newProds.findIndex(p => p.sku === row.sku);
        if (i >= 0) { newProds[i] = { ...newProds[i], ...prod }; updated++; }
      }
    });
    setProducts(newProds);
    const res = { added, updated, unchanged, total: preview.length, newUnits: pendingNewUnits.length };
    setResult(res);
    setLastSync({ file: fileName, imported: added + updated, time: new Date().toLocaleTimeString("pl-PL") });
    const unitMsg = pendingNewUnits.length > 0 ? ` · założono ${pendingNewUnits.length} nowych jednostek` : "";
    showAlert(`✅ Import zakończony: ${added} nowych, ${updated} zaktualizowanych${unitMsg}`, "success");
    setStep(4);
  };

  const reset = () => { setStep(1); setRawData(null); setCsvHeaders([]); setPreview([]); setResult(null); setFileName(""); setEncoding("auto"); setDetectedEncoding(null); setPendingFile(null); setPendingNewUnits([]); };

  const downloadSample = () => {
    const blob = new Blob(["\uFEFF" + SAMPLE_CSV], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "wfmag_export_przyklad.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  const newCount = preview.filter(r => r.status === "new").length;
  const updCount = preview.filter(r => r.status === "update").length;
  const unchCount = preview.filter(r => r.status === "unchanged").length;

  return (
    <>
      <div className="page-header">
        <h1 className="page-title">📥 Import CSV z WF-Mag</h1>
        <button className="btn btn-secondary btn-sm" onClick={downloadSample}>⬇️ Pobierz przykładowy CSV</button>
      </div>

      {/* Kroki */}
      <div className="step-indicator">
        {["1. Wgraj plik", "2. Mapowanie kolumn", "3. Podgląd zmian", "4. Wynik"].map((s, i) => (
          <div key={i} className={`step ${step === i + 1 ? "active" : step > i + 1 ? "done" : ""}`}>
            {step > i + 1 ? "✓ " : ""}{s}
          </div>
        ))}
      </div>

      {/* KROK 1 — Wgraj plik */}
      {step === 1 && (
        <div className="card">
          <div
            className={`csv-dropzone ${dragOver ? "drag-over" : ""}`}
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileRef.current.click()}
          >
            <div className="csv-dropzone-icon">📂</div>
            <div className="csv-dropzone-text">Przeciągnij plik CSV z WF-Mag lub kliknij aby wybrać</div>
            <div className="csv-dropzone-sub">Obsługiwany format: CSV z separatorem średnika (;) · kodowanie UTF-8 lub Windows-1250</div>
            <input ref={fileRef} type="file" accept=".csv,text/csv" style={{ display: "none" }} onChange={handleFile} />
          </div>

          <div className="info-box mb-3">
            <strong>Jak wyeksportować CSV z WF-Mag?</strong><br />
            W programie WF-Mag: <strong>Kartoteki → Artykuły → F10 (Eksport)</strong> lub menu <strong>Raporty → Eksport do pliku</strong>.<br />
            Wybierz format CSV z separatorem średnika. Wymagane kolumny: <em>Indeks, Nazwa, Cena brutto, Stan magazynowy</em>.
          </div>

          <p className="form-label" style={{ marginBottom: 8 }}>Oczekiwany format pliku:</p>
          <div className="csv-format-hint">{`Indeks;Nazwa;Kategoria;Cena netto;Cena brutto;Stan magazynowy;Opis;Jednostka
LAP-001;Laptop Pro 15";Elektronika;4064,23;4999,00;12;Opis produktu;szt
SLU-002;Słuchawki Bluetooth;Elektronika;243,09;299,00;30;Opis produktu;szt`}</div>

          <button className="btn btn-secondary" onClick={downloadSample}>⬇️ Pobierz przykładowy plik CSV</button>
        </div>
      )}

      {/* KROK 2 — Mapowanie */}
      {step === 2 && rawData && (
        <div className="card">
          <div className="alert alert-success">✅ Wczytano plik: <strong>{fileName}</strong> — {rawData.length} wierszy, {csvHeaders.length} kolumn</div>

          <div className="encoding-box">
            <div className="flex items-center gap-2">
              <span>🔤 Wykryte kodowanie: <strong>{detectedEncoding === "windows-1250" ? "Windows-1250 (Środkowoeuropejskie)" : "UTF-8"}</strong></span>
            </div>
            <p className="text-sm text-muted" style={{ margin: "6px 0 10px" }}>
              Jeśli polskie znaki (ą, ę, ł, ż...) wyglądają niepoprawnie w podglądzie poniżej, zmień kodowanie ręcznie:
            </p>
            <div className="flex gap-2">
              <button className={`btn btn-sm ${encoding === "auto" ? "btn-primary" : "btn-secondary"}`} onClick={() => reparseWithEncoding("auto")}>Automatycznie</button>
              <button className={`btn btn-sm ${encoding === "windows-1250" ? "btn-primary" : "btn-secondary"}`} onClick={() => reparseWithEncoding("windows-1250")}>Windows-1250</button>
              <button className={`btn btn-sm ${encoding === "UTF-8" ? "btn-primary" : "btn-secondary"}`} onClick={() => reparseWithEncoding("UTF-8")}>UTF-8</button>
            </div>
          </div>

          <h3 className="card-title">Dopasuj kolumny CSV do pól sklepu</h3>
          <div className="info-box mb-3">
            System automatycznie dopasował kolumny. Sprawdź czy mapowanie jest poprawne i popraw jeśli trzeba.
          </div>
          <div className="mapping-grid">
            {FIELDS.map(f => (
              <div key={f.key} className="mapping-row">
                <span className="mapping-label">{f.label} {f.required && <span style={{ color: "var(--danger)" }}>*</span>}</span>
                <span className="mapping-arrow">→</span>
                <select className="form-select" style={{ flex: 1 }} value={mapping[f.key]} onChange={e => setMapping(m => ({ ...m, [f.key]: e.target.value }))}>
                  <option value="">— pomiń —</option>
                  {csvHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                </select>
              </div>
            ))}
          </div>
          <p className="text-sm text-muted mb-3">Podgląd pierwszego wiersza z CSV:</p>
          <div className="preview-table-wrap" style={{ maxHeight: 120 }}>
            <table className="preview-table">
              <thead><tr>{csvHeaders.map(h => <th key={h}>{h}</th>)}</tr></thead>
              <tbody><tr>{csvHeaders.map(h => <td key={h}>{String(rawData[0]?.[h] ?? "")}</td>)}</tr></tbody>
            </table>
          </div>
          <div className="flex gap-3 mt-4">
            <button className="btn btn-primary" onClick={buildPreview}>Dalej: Podgląd zmian →</button>
            <button className="btn btn-secondary" onClick={reset}>← Wróć</button>
          </div>
        </div>
      )}

      {/* KROK 3 — Podgląd */}
      {step === 3 && (
        <div className="card">
          <h3 className="card-title">Podgląd zmian</h3>
          <div className="changes-summary">
            <div className="change-card c-new"><div className="num">{newCount}</div><div className="lbl">Nowe produkty</div></div>
            <div className="change-card c-upd"><div className="num">{updCount}</div><div className="lbl">Aktualizacje</div></div>
            <div className="change-card c-unch"><div className="num">{unchCount}</div><div className="lbl">Bez zmian</div></div>
          </div>

          {pendingNewUnits.length > 0 && (
            <div className="encoding-box" style={{ marginBottom: 18 }}>
              <div className="flex items-center gap-2" style={{ marginBottom: 6 }}>
                <span>📏 Wykryto {pendingNewUnits.length} {pendingNewUnits.length === 1 ? "nową jednostkę miary" : "nowe jednostki miary"} — zostaną automatycznie założone:</span>
              </div>
              <div className="flex gap-2" style={{ flexWrap: "wrap" }}>
                {pendingNewUnits.map(u => <span key={u.value} className="tag tag-sub">{u.label} ({u.value})</span>)}
              </div>
            </div>
          )}

          <div className="import-legend">
            <span><span className="legend-dot" style={{ background: "#22c55e" }}></span>Nowy produkt</span>
            <span><span className="legend-dot" style={{ background: "#f59e0b" }}></span>Aktualizacja ceny/stanu</span>
            <span><span className="legend-dot" style={{ background: "#e5e7eb" }}></span>Bez zmian</span>
          </div>
          <div className="preview-table-wrap">
            <table className="preview-table">
              <thead>
                <tr>
                  <th>Status</th><th>Indeks</th><th>Nazwa</th><th>Kategoria</th>
                  <th>Cena CSV</th><th>Cena bieżąca</th><th>Stan CSV</th><th>Stan bieżący</th><th>Jednostka</th>
                </tr>
              </thead>
              <tbody>
                {preview.map(row => (
                  <tr key={row.idx} className={`row-${row.status}`}>
                    <td>
                      {row.status === "new" && <span className="badge badge-green">+ Nowy</span>}
                      {row.status === "update" && <span className="badge badge-yellow">↻ Update</span>}
                      {row.status === "unchanged" && <span className="badge badge-gray">= OK</span>}
                    </td>
                    <td style={{ fontFamily: "monospace", fontSize: ".78rem" }}>{row.sku}</td>
                    <td>{row.name}</td>
                    <td><span className="tag">{row.category}</span></td>
                    <td style={{ fontWeight: 700, color: row.existing && row.existing.price !== row.price ? "var(--warning)" : "inherit" }}>{fmt(row.price)}</td>
                    <td className="text-muted">{row.existing ? fmt(row.existing.price) : "—"}</td>
                    <td style={{ fontWeight: 700, color: row.existing && row.existing.stock !== row.stock ? "var(--warning)" : "inherit" }}>{row.stock}</td>
                    <td className="text-muted">{row.existing ? row.existing.stock : "—"}</td>
                    <td>
                      {row.unitIsNew
                        ? <span className="tag tag-sub" title="Nowa jednostka — zostanie założona">{row.unit} 🆕</span>
                        : <span className="text-sm text-muted">{units.find(u => u.value === row.unit)?.label || row.unit}</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex gap-3 mt-4">
            <button className="btn btn-success" onClick={doImport} disabled={newCount + updCount === 0}>
              ✅ Importuj {newCount + updCount > 0 ? `(${newCount + updCount} zmian)` : "— brak zmian"}
            </button>
            <button className="btn btn-secondary" onClick={() => setStep(2)}>← Popraw mapowanie</button>
            <button className="btn btn-secondary" onClick={reset}>✕ Anuluj</button>
          </div>
        </div>
      )}

      {/* KROK 4 — Wynik */}
      {step === 4 && result && (
        <div className="card" style={{ textAlign: "center" }}>
          <div style={{ fontSize: "3rem", marginBottom: 12 }}>🎉</div>
          <h2 style={{ marginBottom: 20 }}>Import zakończony pomyślnie!</h2>
          <div className="changes-summary" style={{ maxWidth: 400, margin: "0 auto 24px" }}>
            <div className="change-card c-new"><div className="num">{result.added}</div><div className="lbl">Nowe produkty</div></div>
            <div className="change-card c-upd"><div className="num">{result.updated}</div><div className="lbl">Zaktualizowane</div></div>
            <div className="change-card c-unch"><div className="num">{result.unchanged}</div><div className="lbl">Bez zmian</div></div>
          </div>
          <p className="text-muted text-sm" style={{ marginBottom: 8 }}>Plik: <strong>{fileName}</strong> · {result.total} wierszy przetworzonych</p>
          {result.newUnits > 0 && <p className="text-sm" style={{ color: "var(--primary)", fontWeight: 600, marginBottom: 20 }}>📏 Założono {result.newUnits} {result.newUnits === 1 ? "nową jednostkę miary" : "nowe jednostki miary"}</p>}
          <div className="flex gap-3 items-center" style={{ justifyContent: "center" }}>
            <button className="btn btn-primary" onClick={reset}>📥 Importuj kolejny plik</button>
          </div>
        </div>
      )}
    </>
  );
}

// ── ADMIN PRODUKTY ────────────────────────────────────────────────────────────
function AdminProducts({ products, setProducts, categories, setCategories, units, setUnits, showAlert, modal, setModal, editItem, setEditItem }) {
  const [form, setForm] = useState({ name: "", category: categories[0]?.name || "", subcategory: "", price: "", stock: "", weight: "", unit: "szt", image: "📦", photo: "", description: "", longDescription: "", specs: [], sku: "" });
  const [newCat, setNewCat] = useState("");
  const [newSub, setNewSub] = useState({});
  const [catFilter, setCatFilter] = useState(categories[0]?.name || "");
  const emojis = ["📦", "💻", "🎧", "📱", "👕", "👟", "🍕", "☕", "📘", "🎒", "⌚", "🏋️", "🎮", "🌿"];

  const handlePhotoUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) return showAlert("Wybierz plik graficzny (JPG, PNG)", "danger");
    if (file.size > 2 * 1024 * 1024) return showAlert("Plik jest większy niż 2 MB — wybierz mniejsze zdjęcie", "danger");
    const reader = new FileReader();
    reader.onload = () => setForm(f => ({ ...f, photo: reader.result }));
    reader.onerror = () => showAlert("Nie udało się wczytać zdjęcia", "danger");
    reader.readAsDataURL(file);
  };

  const openAdd = () => { setForm({ name: "", category: categories[0]?.name || "", subcategory: "", price: "", stock: "", weight: "", unit: "szt", image: "📦", photo: "", description: "", longDescription: "", specs: [], sku: "" }); setEditItem(null); setModal("product"); };
  const openEdit = (p) => { setForm({ ...p, subcategory: p.subcategory || "", price: String(p.price), stock: String(p.stock), weight: String(p.weight || ""), unit: p.unit || "szt", photo: p.photo || "", longDescription: p.longDescription || "", specs: p.specs || [] }); setEditItem(p); setModal("product"); };
  const save = () => {
    if (!form.name || !form.price) return showAlert("Wypełnij wymagane pola", "danger");
    if (!form.category) return showAlert("Wybierz kategorię", "danger");
    if (editItem) setProducts(prev => prev.map(p => p.id === editItem.id ? { ...form, id: editItem.id, price: +form.price, stock: +form.stock, weight: +form.weight || 0 } : p));
    else setProducts(prev => [...prev, { ...form, id: Date.now(), price: +form.price, stock: +form.stock, weight: +form.weight || 0 }]);
    showAlert(editItem ? "Produkt zaktualizowany" : "Produkt dodany"); setModal(null);
  };

  const currentSubcats = (categories.find(c => c.name === form.category)?.subcategories) || [];

  const addCategory = () => {
    const name = newCat.trim();
    if (!name) return;
    if (categories.some(c => c.name.toLowerCase() === name.toLowerCase())) return showAlert("Taka kategoria już istnieje", "danger");
    setCategories(prev => [...prev, { name, subcategories: [] }]);
    setNewCat("");
    showAlert(`Kategoria "${name}" dodana`);
  };

  const removeCategory = (catName) => {
    const inUse = products.filter(p => p.category === catName).length;
    if (inUse > 0) return showAlert(`Nie można usunąć — ${inUse} produktów ma tę kategorię`, "danger");
    setCategories(prev => prev.filter(c => c.name !== catName));
    if (catFilter === catName) setCatFilter("");
    showAlert(`Kategoria "${catName}" usunięta`);
  };

  const addSubcategory = (catName) => {
    const sub = (newSub[catName] || "").trim();
    if (!sub) return;
    const cat = categories.find(c => c.name === catName);
    if (cat.subcategories.some(s => s.toLowerCase() === sub.toLowerCase())) return showAlert("Taka podkategoria już istnieje", "danger");
    setCategories(prev => prev.map(c => c.name === catName ? { ...c, subcategories: [...c.subcategories, sub] } : c));
    setNewSub(prev => ({ ...prev, [catName]: "" }));
    showAlert(`Podkategoria "${sub}" dodana do "${catName}"`);
  };

  const removeSubcategory = (catName, sub) => {
    const inUse = products.filter(p => p.category === catName && p.subcategory === sub).length;
    if (inUse > 0) return showAlert(`Nie można usunąć — ${inUse} produktów ma tę podkategorię`, "danger");
    setCategories(prev => prev.map(c => c.name === catName ? { ...c, subcategories: c.subcategories.filter(s => s !== sub) } : c));
    showAlert(`Podkategoria "${sub}" usunięta`);
  };

  return (
    <>
      <div className="page-header">
        <h1 className="page-title">📦 Produkty</h1>
        <div className="flex gap-2">
          <button className="btn btn-secondary" onClick={() => setModal("categories")}>🏷️ Zarządzaj kategoriami</button>
          <button className="btn btn-primary" onClick={openAdd}>+ Dodaj produkt</button>
        </div>
      </div>
      <div className="stats-grid">
        <div className="stat-card"><div className="stat-value">{products.length}</div><div className="stat-label">Produktów</div></div>
        <div className="stat-card"><div className="stat-value">{products.reduce((s, p) => s + p.stock, 0)}</div><div className="stat-label">Sztuk w magazynie</div></div>
        <div className="stat-card"><div className="stat-value">{categories.length}</div><div className="stat-label">Kategorii</div></div>
        <div className="stat-card"><div className="stat-value">{categories.reduce((s, c) => s + c.subcategories.length, 0)}</div><div className="stat-label">Podkategorii</div></div>
      </div>
      <div className="card">
        <div className="table-wrap">
          <table>
            <thead><tr><th>SKU</th><th>Produkt</th><th>Kategoria</th><th>Podkategoria</th><th>Cena</th><th>Waga</th><th>Magazyn</th><th>Akcje</th></tr></thead>
            <tbody>{products.map(p => (
              <tr key={p.id}>
                <td style={{ fontFamily: "monospace", fontSize: ".78rem", color: "var(--muted)" }}>{p.sku || "—"}</td>
                <td>
                  {p.photo
                    ? <img src={p.photo} alt={p.name} className="product-photo-thumb" />
                    : <span style={{ fontSize: "1.2rem", marginRight: 7 }}>{p.image}</span>}
                  <strong>{p.name}</strong>
                </td>
                <td><span className="badge badge-blue">{p.category}</span></td>
                <td>{p.subcategory ? <span className="badge badge-gray">{p.subcategory}</span> : <span className="text-muted text-sm">—</span>}</td>
                <td className="font-bold" style={{ color: "var(--primary)" }}>{fmt(p.price)}</td>
                <td className="text-sm text-muted">{p.weight ? `${p.weight} kg` : "—"}</td>
                <td><span className={`badge ${p.stock > 10 ? "badge-green" : p.stock > 0 ? "badge-orange" : "badge-red"}`}>{p.stock} {units.find(u => u.value === p.unit)?.label || "szt."}</span></td>
                <td><div className="flex gap-2">
                  <button className="btn btn-secondary btn-sm" onClick={() => openEdit(p)}>✏️</button>
                  <button className="btn btn-danger btn-sm" onClick={() => { setProducts(prev => prev.filter(x => x.id !== p.id)); showAlert("Usunięto"); }}>🗑️</button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>

      {modal === "product" && (
        <div className="modal-bg">
          <div className="modal">
            <div className="modal-header"><h2 className="modal-title">{editItem ? "Edytuj produkt" : "Nowy produkt"}</h2><button className="close-btn" onClick={() => setModal(null)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label">Zdjęcie produktu</label>
                <div className="photo-upload-row">
                  <div className="photo-preview">
                    {form.photo ? <img src={form.photo} alt="podgląd" /> : <span style={{ fontSize: "2.2rem" }}>{form.image}</span>}
                  </div>
                  <div className="flex gap-2" style={{ flexDirection: "column" }}>
                    <label className="btn btn-secondary btn-sm" style={{ cursor: "pointer", width: "fit-content" }}>
                      📷 {form.photo ? "Zmień zdjęcie" : "Wgraj zdjęcie"}
                      <input type="file" accept="image/*" style={{ display: "none" }} onChange={handlePhotoUpload} />
                    </label>
                    {form.photo && <button type="button" className="btn btn-danger btn-sm" style={{ width: "fit-content" }} onClick={() => setForm(f => ({ ...f, photo: "" }))}>🗑️ Usuń zdjęcie</button>}
                    <span className="text-sm text-muted">JPG/PNG, max 2 MB. Bez zdjęcia produkt wyświetli ikonę.</span>
                  </div>
                </div>
              </div>
              <div className="form-group"><label className="form-label">Ikona (gdy brak zdjęcia)</label>
                <div className="flex gap-2" style={{ flexWrap: "wrap" }}>
                  {emojis.map(e => <button key={e} onClick={() => setForm(f => ({ ...f, image: e }))} style={{ fontSize: "1.4rem", padding: "5px 9px", borderRadius: 8, border: `2px solid ${form.image === e ? "var(--primary)" : "var(--border)"}`, background: form.image === e ? "var(--primary-light)" : "#fff", cursor: "pointer" }}>{e}</button>)}
                </div>
              </div>
              <div className="flex gap-3">
                <div className="form-group" style={{ flex: 2 }}><label className="form-label">Nazwa *</label><input className="form-input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
                <div className="form-group" style={{ flex: 1 }}><label className="form-label">SKU / Indeks</label><input className="form-input" value={form.sku} onChange={e => setForm(f => ({ ...f, sku: e.target.value }))} /></div>
              </div>
              <div className="flex gap-3">
                <div className="form-group" style={{ flex: 1 }}>
                  <label className="form-label">Kategoria *</label>
                  <select className="form-select" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value, subcategory: "" }))}>
                    <option value="">— wybierz —</option>
                    {categories.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
                  </select>
                </div>
                <div className="form-group" style={{ flex: 1 }}>
                  <label className="form-label">Podkategoria</label>
                  <select className="form-select" value={form.subcategory} onChange={e => setForm(f => ({ ...f, subcategory: e.target.value }))} disabled={!form.category || currentSubcats.length === 0}>
                    <option value="">— brak —</option>
                    {currentSubcats.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <button type="button" className="btn btn-secondary btn-sm w-full" style={{ marginTop: -6, marginBottom: 14 }} onClick={() => setModal("categories")}>🏷️ Zarządzaj kategoriami i podkategoriami</button>
              <div className="form-group"><label className="form-label">Opis (krótki, widoczny na karcie produktu)</label><input className="form-input" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} /></div>

              <div className="form-group">
                <label className="form-label">Rozszerzony opis (strona produktu)</label>
                <RichTextEditor
                  value={form.longDescription}
                  onChange={html => setForm(f => ({ ...f, longDescription: html }))}
                  placeholder="Opisz produkt szerzej — możesz formatować tekst, zmieniać kolory i wstawiać obrazy..."
                />
              </div>

              <div className="form-group">
                <label className="form-label">Specyfikacja techniczna</label>
                {form.specs.map((row, i) => (
                  <div key={i} className="spec-row-editor">
                    <input className="form-input" placeholder="Parametr (np. Materiał)" value={row.key}
                      onChange={e => setForm(f => ({ ...f, specs: f.specs.map((s, si) => si === i ? { ...s, key: e.target.value } : s) }))} />
                    <input className="form-input" placeholder="Wartość (np. Stal nierdzewna)" value={row.value}
                      onChange={e => setForm(f => ({ ...f, specs: f.specs.map((s, si) => si === i ? { ...s, value: e.target.value } : s) }))} />
                    <button type="button" className="btn btn-danger btn-sm" onClick={() => setForm(f => ({ ...f, specs: f.specs.filter((_, si) => si !== i) }))}>✕</button>
                  </div>
                ))}
                <button type="button" className="btn btn-secondary btn-sm" onClick={() => setForm(f => ({ ...f, specs: [...f.specs, { key: "", value: "" }] }))}>+ Dodaj parametr</button>
              </div>

              <div className="flex gap-3">
                <div className="form-group" style={{ flex: 1 }}><label className="form-label">Cena brutto *</label><input className="form-input" type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} /></div>
                <div className="form-group" style={{ flex: 1 }}><label className="form-label">Stan magazynowy</label><input className="form-input" type="number" value={form.stock} onChange={e => setForm(f => ({ ...f, stock: e.target.value }))} /></div>
              </div>
              <div className="flex gap-3">
                <div className="form-group" style={{ flex: 1 }}>
                  <label className="form-label">Jednostka miary</label>
                  <select className="form-select" value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))}>
                    {units.map(u => <option key={u.value} value={u.value}>{u.label}</option>)}
                  </select>
                </div>
                <div className="form-group" style={{ flex: 1 }}><label className="form-label">Waga (kg)</label><input className="form-input" type="number" step="0.01" min="0" placeholder="np. 1.5" value={form.weight} onChange={e => setForm(f => ({ ...f, weight: e.target.value }))} /></div>
              </div>
              <div className="flex gap-3 mt-4">
                <button className="btn btn-primary" style={{ flex: 1 }} onClick={save}>💾 {editItem ? "Zapisz" : "Dodaj"}</button>
                <button className="btn btn-secondary" onClick={() => setModal(null)}>Anuluj</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {modal === "categories" && (
        <div className="modal-bg">
          <div className="modal" style={{ maxWidth: 600 }}>
            <div className="modal-header"><h2 className="modal-title">🏷️ Zarządzanie kategoriami i podkategoriami</h2><button className="close-btn" onClick={() => setModal(null)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label">Nowa kategoria główna</label>
                <div className="flex gap-2">
                  <input className="form-input" value={newCat} onChange={e => setNewCat(e.target.value)} placeholder="np. Odzież" onKeyDown={e => e.key === "Enter" && addCategory()} />
                  <button className="btn btn-primary btn-sm" onClick={addCategory}>+ Dodaj kategorię</button>
                </div>
              </div>
              <div className="divider"></div>
              <p className="form-label mb-3">Kategorie i ich podkategorie:</p>

              {categories.length === 0
                ? <p className="text-sm text-muted">Brak kategorii — dodaj pierwszą powyżej.</p>
                : <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {categories.map(cat => {
                    const count = products.filter(p => p.category === cat.name).length;
                    const isOpen = catFilter === cat.name;
                    return (
                      <div key={cat.name} className="category-block">
                        <div className="category-block-header" onClick={() => setCatFilter(isOpen ? "" : cat.name)}>
                          <span style={{ fontWeight: 600 }}>{isOpen ? "▾" : "▸"} {cat.name}</span>
                          <span className="text-sm text-muted">{count} produktów · {cat.subcategories.length} podkategorii</span>
                          <button onClick={e => { e.stopPropagation(); removeCategory(cat.name); }} className="cat-remove-btn" title="Usuń kategorię">✕</button>
                        </div>
                        {isOpen && (
                          <div className="category-block-body">
                            {cat.subcategories.length === 0
                              ? <p className="text-sm text-muted" style={{ marginBottom: 10 }}>Brak podkategorii.</p>
                              : <div className="flex gap-2 mb-3" style={{ flexWrap: "wrap" }}>
                                {cat.subcategories.map(sub => {
                                  const subCount = products.filter(p => p.category === cat.name && p.subcategory === sub).length;
                                  return (
                                    <span key={sub} className="tag tag-sub" style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 6px 5px 10px" }}>
                                      {sub} <span className="text-muted">({subCount})</span>
                                      <button onClick={() => removeSubcategory(cat.name, sub)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--danger)", fontWeight: 700, padding: "0 3px" }} title="Usuń podkategorię">✕</button>
                                    </span>
                                  );
                                })}
                              </div>}
                            <div className="flex gap-2">
                              <input className="form-input" style={{ fontSize: ".82rem" }} placeholder={`Nowa podkategoria w "${cat.name}"`}
                                value={newSub[cat.name] || ""} onChange={e => setNewSub(prev => ({ ...prev, [cat.name]: e.target.value }))}
                                onKeyDown={e => e.key === "Enter" && addSubcategory(cat.name)} />
                              <button className="btn btn-secondary btn-sm" onClick={() => addSubcategory(cat.name)}>+ Dodaj</button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>}

              <div className="flex gap-3 mt-4">
                <button className="btn btn-primary w-full" onClick={() => setModal(null)}>Zamknij</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ── ADMIN KLIENCI ─────────────────────────────────────────────────────────────
function AdminUsers({ users, setUsers, showAlert, modal, setModal, editItem, setEditItem }) {
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "customer", discount: "0" });
  const openEdit = (u) => { setForm({ ...u, discount: String(u.discount) }); setEditItem(u); setModal("user"); };
  const openAdd = () => { setForm({ name: "", email: "", password: "", role: "customer", discount: "0" }); setEditItem(null); setModal("user"); };
  const save = () => {
    if (!form.name || !form.email) return showAlert("Wypełnij wymagane pola", "danger");
    if (editItem) setUsers(prev => prev.map(u => u.id === editItem.id ? { ...form, id: editItem.id, discount: +form.discount } : u));
    else setUsers(prev => [...prev, { ...form, id: Date.now(), discount: +form.discount }]);
    showAlert(editItem ? "Klient zaktualizowany" : "Klient dodany"); setModal(null);
  };
  return (
    <>
      <div className="page-header"><h1 className="page-title">👥 Klienci</h1><button className="btn btn-primary" onClick={openAdd}>+ Dodaj klienta</button></div>
      <div className="stats-grid">
        <div className="stat-card"><div className="stat-value">{users.filter(u => u.role === "customer").length}</div><div className="stat-label">Klientów</div></div>
        <div className="stat-card"><div className="stat-value">{users.filter(u => u.discount > 0).length}</div><div className="stat-label">Z rabatem</div></div>
      </div>
      <div className="card">
        <div className="table-wrap">
          <table>
            <thead><tr><th>Klient</th><th>Email</th><th>Rola</th><th>Rabat</th><th>Akcje</th></tr></thead>
            <tbody>{users.map(u => (
              <tr key={u.id}>
                <td><strong>{u.name}</strong></td>
                <td className="text-muted">{u.email}</td>
                <td><span className={`badge ${u.role === "admin" ? "badge-orange" : "badge-blue"}`}>{u.role === "admin" ? "🔧 Admin" : "👤 Klient"}</span></td>
                <td>{u.discount > 0 ? <span className="badge badge-green">🎉 {u.discount}%</span> : <span className="badge badge-gray">Brak</span>}</td>
                <td><button className="btn btn-secondary btn-sm" onClick={() => openEdit(u)}>✏️ Edytuj rabat</button></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>
      {modal === "user" && (
        <div className="modal-bg">
          <div className="modal">
            <div className="modal-header"><h2 className="modal-title">{editItem ? "Edytuj klienta" : "Nowy klient"}</h2><button className="close-btn" onClick={() => setModal(null)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group"><label className="form-label">Imię i nazwisko *</label><input className="form-input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
              <div className="form-group"><label className="form-label">Email *</label><input className="form-input" type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} /></div>
              <div className="form-group"><label className="form-label">Hasło</label><input className="form-input" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} /></div>
              <div className="flex gap-3">
                <div className="form-group" style={{ flex: 1 }}><label className="form-label">Rola</label>
                  <select className="form-select" value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))}><option value="customer">Klient</option><option value="admin">Admin</option></select>
                </div>
                <div className="form-group" style={{ flex: 1 }}><label className="form-label">Rabat (%)</label><input className="form-input" type="number" min="0" max="100" value={form.discount} onChange={e => setForm(f => ({ ...f, discount: e.target.value }))} /></div>
              </div>
              <div className="flex gap-3 mt-4">
                <button className="btn btn-primary" style={{ flex: 1 }} onClick={save}>💾 {editItem ? "Zapisz" : "Dodaj"}</button>
                <button className="btn btn-secondary" onClick={() => setModal(null)}>Anuluj</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ── ZAMÓWIENIA ────────────────────────────────────────────────────────────────
function OrdersPage({ orders, isAdmin, units }) {
  return (
    <>
      <div className="page-header"><h1 className="page-title">📋 {isAdmin ? "Wszystkie zamówienia" : "Moje zamówienia"}</h1></div>
      {orders.length === 0
        ? <div className="empty-state"><div className="icon">📋</div>Brak zamówień</div>
        : orders.map(o => (
          <div key={o.id} className="card" style={{ marginBottom: 14 }}>
            <div className="flex items-center gap-3" style={{ marginBottom: 10, flexWrap: "wrap" }}>
              <span className="font-bold">#{o.id.toString().slice(-6)}</span>
              <span className="badge badge-blue">{o.date}</span>
              {isAdmin && <span className="badge badge-orange">👤 {o.user}{o.guestEmail ? ` (${o.guestEmail})` : ""}</span>}
              {o.paymentMethod && <span className="badge badge-blue">💳 {o.paymentMethod}</span>}
              {o.paymentStatus && <span className={`badge ${o.paymentStatus === "Opłacone" ? "badge-green" : "badge-yellow"}`}>{o.paymentStatus === "Opłacone" ? "✅" : "⏳"} {o.paymentStatus}</span>}
              {o.shipmentLabel && <span className="badge badge-gray">{o.shipmentType === "packages" ? "📦" : "🪵"} {o.shipmentLabel}</span>}
              <span className="badge badge-green ml-auto">{o.status}</span>
            </div>
            <div className="table-wrap">
              <table>
                <thead><tr><th>Produkt</th><th>Cena</th><th>Ilość</th><th>Suma</th></tr></thead>
                <tbody>{o.items.map(i => <tr key={i.id}><td>{i.photo ? <img src={i.photo} alt={i.name} className="product-photo-thumb" /> : i.image} {i.name}</td><td>{fmt(i.price)}</td><td>{i.qty} {units.find(u => u.value === i.unit)?.label || "szt."}</td><td className="font-bold">{fmt(i.price * i.qty)}</td></tr>)}</tbody>
              </table>
            </div>
            <div style={{ marginTop: 10, textAlign: "right", borderTop: "1px solid var(--border)", paddingTop: 8 }}>
              {o.discount > 0 && <span className="text-sm" style={{ color: "var(--success)", marginRight: 12 }}>Rabat {o.discount}%: −{fmt(o.discountAmt)}</span>}
              <span className="text-sm text-muted" style={{ marginRight: 12 }}>
                Dostawa: {o.freeShipping ? <span style={{ color: "var(--success)", fontWeight: 600 }}>Gratis</span> : fmt(o.shippingCost || 0)}
              </span>
              <span className="font-bold" style={{ color: "var(--primary)", fontSize: "1rem" }}>Do zapłaty: {fmt(o.total)}</span>
            </div>
          </div>
        ))}
    </>
  );
}
